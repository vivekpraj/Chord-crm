"""
AM:PM — AI News Video Production Pipeline
Streamlit UI: 4 screens — Input, Script Review, Generation Progress, Output
"""
import concurrent.futures
import io
import json
import logging
import re
import zipfile
from pathlib import Path

import streamlit as st

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    datefmt="%H:%M:%S",
)

import config
from core.ffmpeg_utils import merge_cutaway_audio
from core.higgsfield_cli import animate_cutaway_scenes, generate_all_images
from core.script_generator import generate_script, scenes_from_script, summarize_article
from core.voice_generator import generate_audio_for_scenes
from models.persona import PERSONA_BANK, BEAT_TO_PERSONA
from models.scene import Scene
from models.templates import STORY_TEMPLATES

st.set_page_config(
    page_title="AM:PM Video Pipeline",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="collapsed",
)

def _save_uploaded_image(uploaded_file, dest_dir: Path) -> str:
    """Save uploaded image with correct extension based on actual file bytes, not filename."""
    data = uploaded_file.read()
    ext = Path(uploaded_file.name).suffix.lower()
    if data[:3] == b"\xff\xd8\xff":
        ext = ".jpg"
    elif data[:8] == b"\x89PNG\r\n\x1a\n":
        ext = ".png"
    dest_dir.mkdir(exist_ok=True)
    save_path = str(dest_dir / (Path(uploaded_file.name).stem + ext))
    with open(save_path, "wb") as f:
        f.write(data)
    return save_path


# ── Brand CSS ─────────────────────────────────────────────────────────────────
st.markdown("""
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');
  html, body, [class*="css"] { font-family: 'Inter', sans-serif; }

  .ampm-header {
    background: #0D0D0B;
    color: #AAFF47;
    padding: 1.2rem 1.5rem;
    border-radius: 8px;
    margin-bottom: 1.5rem;
    font-size: 1.4rem;
    font-weight: 700;
    letter-spacing: -0.5px;
  }
  .scene-card {
    background: #F0EDE5;
    border-left: 4px solid #AAFF47;
    padding: 1rem 1.2rem;
    border-radius: 6px;
    margin-bottom: 1rem;
    color: #0D0D0B;
  }
  .scene-card.avatar { border-left-color: #AAFF47; }
  .scene-card.cutaway { border-left-color: #0D0D0B; }
  .tag {
    display: inline-block;
    padding: 2px 10px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 600;
    margin-bottom: 0.5rem;
  }
  .tag-avatar { background: #AAFF47; color: #0D0D0B; }
  .tag-cutaway { background: #0D0D0B; color: #AAFF47; }
  .tag-textcard { background: #F0EDE5; color: #0D0D0B; border: 1px solid #0D0D0B; }
  .status-ok { color: #22c55e; font-weight: 600; }
  .status-warn { color: #f59e0b; font-weight: 600; }
  .status-err { color: #ef4444; font-weight: 600; }
</style>
""", unsafe_allow_html=True)

# ── Session state initialisation ───────────────────────────────────────────────
def _init_state():
    defaults = {
        "screen": "input",
        "script_data": None,
        "scenes": None,
        "video_id": None,
        "output_dir": None,
        "generation_log": [],
        "final_scenes": None,
        # news source state
        "news_content_edit": "",
        "fetch_status": None,   # None | "ok" | "empty" | "error"
        "fetch_error_msg": "",
        "avatar_image_path": None,
        "voice_ref_upload_path": None,
        "animation_model": "seedance_2_0_mini",
        "video_type": "mode1",
        "lipsync_characters": [],
        "lipsync_script_raw": "",
        "include_text_cards": True,
        "video_duration": 40,
        "scene_sequence": [],
        "lipsync_use_as_is": False,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

_init_state()

# ── Header ─────────────────────────────────────────────────────────────────────
st.markdown('<div class="ampm-header">AM:PM — AI Video Pipeline</div>', unsafe_allow_html=True)

# ── Top nav: Upload existing script ───────────────────────────────────────────
with st.expander("Upload existing script JSON", expanded=False):
    uploaded_script = st.file_uploader(
        "Drop any saved script JSON (mode1 / mode2 / mode3 / lipsync)",
        type=["json"],
        key="script_upload",
        label_visibility="collapsed",
    )
    if uploaded_script is not None and st.session_state.get("_last_upload") != uploaded_script.name:
        try:
            raw = uploaded_script.read().decode("utf-8")
            data = json.loads(raw)

            vtype = data.get("video_type", "")
            # Normalise legacy names
            if vtype == "drama":
                vtype = "mode3"
            elif vtype == "type1":
                vtype = "mode1"
            elif vtype == "type2":
                vtype = "mode2"

            VALID_TYPES = ("mode1", "mode2", "mode3", "lipsync")
            if vtype not in VALID_TYPES:
                st.error(f"Unrecognised video_type '{data.get('video_type')}'. Expected one of: {', '.join(VALID_TYPES)}.")
            else:
                data["video_type"] = vtype
                video_id = data.get("video_id", "uploaded")
                output_dir = config.OUTPUT_DIR / video_id
                output_dir.mkdir(parents=True, exist_ok=True)
                (output_dir / "script.json").write_text(
                    json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8"
                )
                # Copy AMPM final card if available
                _fc_src = config.AMPM_FINAL_CARD
                _fc_dst = output_dir / "AMPM-FINAL_CARD.mp4"
                if _fc_src.exists() and not _fc_dst.exists():
                    import shutil as _shutil
                    _shutil.copy2(_fc_src, _fc_dst)

                st.session_state["script_data"] = data
                st.session_state["video_id"]    = video_id
                st.session_state["output_dir"]  = str(output_dir)
                st.session_state["video_type"]  = vtype

                # Restore character image + voice ref if embedded in JSON and files still exist
                _json_img = data.get("character_image_path", "")
                if _json_img and Path(_json_img).exists():
                    st.session_state["avatar_image_path"] = _json_img
                _json_vr = data.get("voice_ref_path", "")
                if _json_vr and Path(_json_vr).exists():
                    st.session_state["voice_ref_upload_path"] = _json_vr

                if vtype == "lipsync":
                    # Restore character image list from embedded JSON
                    _ls_chars = data.get("lipsync_characters", [])
                    if _ls_chars:
                        st.session_state["lipsync_characters"] = _ls_chars
                    st.session_state["screen"] = "lipsync_review"
                else:
                    # mode1 / mode2 need flat scenes list; mode3 review handles its own structure
                    if vtype != "mode3":
                        from core.script_generator import scenes_from_script
                        st.session_state["scenes"] = scenes_from_script(data)
                    st.session_state["screen"] = "review"

                st.session_state["_last_upload"] = uploaded_script.name
                st.success(f"Loaded {vtype} script — {video_id}")
                st.rerun()
        except json.JSONDecodeError as e:
            st.error(f"Invalid JSON: {e}")
        except Exception as e:
            st.error(f"Failed to load script: {e}")

# ── Sidebar: env check ─────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### LLM Provider")
    _provider_labels = {
        "claude": "Claude Sonnet (default)",
        "groq":   "Groq — Llama 3.3 70B",
    }
    provider = st.selectbox(
        "Script generation model",
        list(_provider_labels.keys()),
        index=0,
        format_func=lambda x: _provider_labels[x],
        label_visibility="collapsed",
    )
    st.session_state["llm_provider"] = provider

    st.markdown("### Video Model")
    _ANIM_OPTIONS = ["seedance_2_0_mini", "seedance_2_0"]
    _ANIM_LABELS  = {
        "seedance_2_0_mini": "Seedance 2.0 Mini (default)",
        "seedance_2_0":      "Seedance 2.0 Fast",
    }
    _cur = st.session_state.get("animation_model", "seedance_2_0_mini")
    if _cur not in _ANIM_OPTIONS:
        _cur = "seedance_2_0_mini"
    animation_model = st.selectbox(
        "Video model",
        _ANIM_OPTIONS,
        index=_ANIM_OPTIONS.index(_cur),
        format_func=lambda x: _ANIM_LABELS[x],
        label_visibility="collapsed",
    )
    st.session_state["animation_model"] = animation_model

    st.markdown("### Text Cards")
    include_tc = st.toggle(
        "Include text cards",
        value=st.session_state.get("include_text_cards", True),
        key="include_text_cards_toggle",
        help="Off = skip text card generation entirely.",
    )
    st.session_state["include_text_cards"] = include_tc

    env = config.check_env()
    for key, label in {"groq": "Groq API", "claude": "Claude API"}.items():
        ok = env[key]
        active = provider == key
        if ok:
            icon = "status-ok"
            dot = "Connected" + (" — active" if active else "")
        else:
            icon = "status-warn"
            dot = "Not configured"
        st.markdown(f'<span class="{icon}">{label}: {dot}</span>', unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("### Service Status")
    for key, label in {"elevenlabs": "ElevenLabs"}.items():
        ok = env[key]
        icon = "status-ok" if ok else "status-warn"
        dot = "Connected" if ok else "Not configured"
        st.markdown(f'<span class="{icon}">{label}: {dot}</span>', unsafe_allow_html=True)

    st.markdown("---")
    st.markdown("**Higgsfield CLI**")
    import subprocess, shutil
    _HIGGSFIELD_FALLBACK = (
        r"C:\Users\HR 1\AppData\Roaming\fnm\node-versions\v20.20.2\installation\higgsfield.cmd"
    )
    _hf_path = shutil.which("higgsfield") or (
        _HIGGSFIELD_FALLBACK if Path(_HIGGSFIELD_FALLBACK).exists() else None
    )
    if _hf_path:
        st.markdown('<span class="status-ok">Connected</span>', unsafe_allow_html=True)
    else:
        st.markdown('<span class="status-err">Not found</span>', unsafe_allow_html=True)

    # ── Re-animate from saved images ──────────────────────────────────────────
    if st.session_state.get("output_dir") and st.session_state.get("scenes"):
        output_dir_check = Path(st.session_state["output_dir"])
        images_exist = any((output_dir_check / "images").glob("scene*_cutaway.jpg"))
        if images_exist:
            st.markdown("---")
            st.markdown("**Resume**")
            anim_model_resume = st.selectbox(
                "Model for re-animation",
                ["seedance_2_0_mini", "seedance_2_0"],
                index=["seedance_2_0_mini", "seedance_2_0"].index(st.session_state.get("animation_model", "seedance_2_0_mini")),
                format_func=lambda x: {"seedance_2_0_mini": "Seedance 2.0 Mini", "seedance_2_0": "Seedance 2.0 Fast"}[x],
                key="resume_model_select",
                label_visibility="collapsed",
            )
            if st.button("Re-animate from saved images", use_container_width=True):
                st.session_state["animation_model"] = anim_model_resume
                st.session_state["screen"] = "reanimate"
                st.rerun()

    # ── Character image — always visible in sidebar ────────────
    _sb_vtype = st.session_state.get("video_type", "mode1")
    if _sb_vtype == "lipsync":
        st.markdown("---")
        st.markdown("### Characters")
        _sb_ls_chars = st.session_state.get("lipsync_characters", [])
        if _sb_ls_chars:
            for _c in _sb_ls_chars:
                _cimg = _c.get("image_path", "")
                if _cimg and Path(_cimg).exists():
                    st.image(_cimg, width=80, caption=_c["name"])
                else:
                    st.caption(f"{_c['name']} — no image")
        else:
            st.caption("Add characters in the input screen.")
        _sb_ls_vref_cur = st.session_state.get("voice_ref_upload_path") or ""
        if _sb_ls_vref_cur and Path(_sb_ls_vref_cur).exists():
            st.markdown("### Voice Ref")
            st.caption(f"{Path(_sb_ls_vref_cur).name}")
    elif _sb_vtype in ("mode1", "mode2"):
        st.markdown("---")
        st.markdown("### Character")
        _sb_char_file = st.file_uploader(
            "Reference image (JPG/PNG)",
            type=["jpg", "jpeg", "png"],
            key="sb_char_img",
            label_visibility="collapsed",
        )
        if _sb_char_file:
            _sb_save = _save_uploaded_image(_sb_char_file, config.OUTPUT_DIR / "_avatars")
            st.session_state["avatar_image_path"] = _sb_save
        _sb_cur = st.session_state.get("avatar_image_path") or ""
        if _sb_cur and Path(_sb_cur).exists():
            st.image(_sb_cur, width=100, caption=Path(_sb_cur).name)
        elif not _sb_char_file:
            st.warning("No character image — upload one above. Avatar scenes will generate without reference.")

        st.markdown("### Voice Ref (optional)")
        _sb_voice_file = st.file_uploader(
            "Voice reference (MP3/WAV)",
            type=["mp3", "wav"],
            key="sb_voice_ref",
            label_visibility="collapsed",
        )
        if _sb_voice_file:
            _sb_voice_tmp = config.OUTPUT_DIR / "_avatars"
            _sb_voice_tmp.mkdir(exist_ok=True)
            _sb_voice_save = str(_sb_voice_tmp / _sb_voice_file.name)
            with open(_sb_voice_save, "wb") as f:
                f.write(_sb_voice_file.read())
            st.session_state["voice_ref_upload_path"] = _sb_voice_save
        _sb_vref_cur = st.session_state.get("voice_ref_upload_path") or ""
        if _sb_vref_cur and Path(_sb_vref_cur).exists():
            st.caption(f"Voice ref: {Path(_sb_vref_cur).name}")

    st.markdown("---")
    if st.button("Reset / New Video"):
        for key in ["script_data", "scenes", "video_id", "output_dir", "generation_log", "final_scenes", "avatar_image_path", "voice_ref_upload_path"]:
            st.session_state[key] = None
        st.session_state["generation_log"] = []
        st.session_state["news_content_edit"] = ""
        st.session_state["fetch_status"] = None
        st.session_state["fetch_error_msg"] = ""
        st.session_state["lipsync_characters"] = []
        st.session_state["lipsync_script_raw"] = ""
        st.session_state["screen"] = "input"
        st.rerun()


# ═══════════════════════════════════════════════════════════════════════════════
# Scene sequence builder
# ═══════════════════════════════════════════════════════════════════════════════
_SCENE_DURATIONS = {"LIPSYNC": 8, "INFOGRAPHIC": 8, "TEXT_CARD": 4}
_DURATION_OPTIONS = [32, 40, 48, 60]


def _render_scene_builder(video_type: str):
    st.markdown("### Video Structure")
    duration = st.radio(
        "Total duration",
        _DURATION_OPTIONS,
        format_func=lambda x: f"{x}s",
        index=_DURATION_OPTIONS.index(st.session_state.get("video_duration", 40)),
        horizontal=True,
        key="duration_radio",
    )
    if duration != st.session_state.get("video_duration"):
        st.session_state["video_duration"] = duration
        st.session_state["scene_sequence"] = []
        st.rerun()

    seq = st.session_state.get("scene_sequence", [])
    used = sum(_SCENE_DURATIONS[s] for s in seq)
    remaining = duration - used

    col_l, col_i, col_t, col_clr = st.columns([2, 2, 2, 1])
    with col_l:
        if st.button(f"+ Lipsync (8s)", disabled=remaining < 8, use_container_width=True):
            seq.append("LIPSYNC"); st.session_state["scene_sequence"] = seq; st.rerun()
    with col_i:
        if st.button(f"+ Infographic (8s)", disabled=remaining < 8, use_container_width=True):
            seq.append("INFOGRAPHIC"); st.session_state["scene_sequence"] = seq; st.rerun()
    with col_t:
        if st.button(f"+ Text Card (4s)", disabled=remaining < 4, use_container_width=True):
            seq.append("TEXT_CARD"); st.session_state["scene_sequence"] = seq; st.rerun()
    with col_clr:
        if st.button("Clear", use_container_width=True):
            st.session_state["scene_sequence"] = []; st.rerun()

    if seq:
        st.caption(f"Sequence: {' → '.join(seq)}  |  {used}s used, {remaining}s remaining")
        cols = st.columns(len(seq))
        for i, (stype, col) in enumerate(zip(seq, cols)):
            with col:
                label = {"LIPSYNC": "🎙 Lipsync", "INFOGRAPHIC": "📊 Info", "TEXT_CARD": "📝 Card"}[stype]
                st.markdown(f"**{i+1}. {label}**")
                if st.button("×", key=f"rm_seq_{i}"):
                    seq.pop(i); st.session_state["scene_sequence"] = seq; st.rerun()
        if remaining == 0:
            st.success("Duration filled — ready to generate.")
    else:
        st.caption(f"{remaining}s remaining. Add scenes above.")


# ═══════════════════════════════════════════════════════════════════════════════
# SCREEN 1 — INPUT
# ═══════════════════════════════════════════════════════════════════════════════
def screen_input():
    st.markdown("## New Video")

    # ── Video format selector ──────────────────────────────────────────────────
    _vt_options = ["lipsync", "mode1", "mode2", "mode3"]
    _vt_current = st.session_state.get("video_type", "mode1")
    if _vt_current not in _vt_options:
        _vt_current = "mode1"
    _vt_index = _vt_options.index(_vt_current)
    video_type = st.radio(
        "Video format",
        _vt_options,
        format_func=lambda x: {
            "lipsync": "Type 1 — Lipsync (your script + character images)",
            "mode1":   "Type 2 Mode 1 — Standard (2 avatar + 4 cutaway, 60s)",
            "mode2":   "Type 2 Mode 2 — Split-screen (2 avatar 30s + 10 cutaway 5s, 4:3)",
            "mode3":   "Type 2 Mode 3 — Micro-Drama (2 characters, dialogue, 60s)",
        }[x],
        horizontal=True,
        index=_vt_index,
    )
    st.session_state["video_type"] = video_type
    if video_type == "lipsync":
        st.caption("Type 1: Paste your own script. Add character images. Format into scenes. Generate each clip individually.")
    elif video_type == "mode2":
        st.caption("Split-screen: avatar speaks top 2/3, 12 silent infographic clips (5s each, 4:3) run bottom 1/3 simultaneously.")
    elif video_type == "mode3":
        st.caption("Two-character micro-drama: Character 1 (human cost) + Character 2 (systemic failure) converge at a shared truth. 60s, 9:16.")

    st.markdown("---")

    # ── Duration + scene sequence builder (all types except drama) ────────────
    if video_type != "mode3":
        _render_scene_builder(video_type)
        st.markdown("---")

    # Type 1 Lipsync — separate input flow
    if video_type == "lipsync":
        _render_lipsync_input()
        return

    col1, col2 = st.columns([2, 1])

    with col1:
        topic = st.text_area(
            "Topic / editorial angle",
            placeholder="RBI data shows services sector credit growth outpacing manufacturing for 3rd consecutive quarter",
            height=100,
        )

    with col2:
        _beats = ["Finance", "Business", "Politics", "Culture", "Global Affairs", "Crime/Tragedy", "Science/Tech", "Health"]
        _auto_beat = st.session_state.get("auto_beat", "Politics")
        beat = st.selectbox(
            "Beat",
            _beats,
            index=_beats.index(_auto_beat) if _auto_beat in _beats else 2,
            help="Auto-selected from article" if st.session_state.get("auto_beat") else None,
        )
        language = st.selectbox("Language", ["Hinglish", "English", "Hindi"])
        _tones = ["Calm", "Energetic", "Serious", "Casual"]
        _auto_tone = st.session_state.get("auto_tone", "Serious")
        tone = st.selectbox(
            "Tone",
            _tones,
            index=_tones.index(_auto_tone) if _auto_tone in _tones else 2,
            help="Auto-selected from article" if st.session_state.get("auto_tone") else None,
        )

    col3, col4 = st.columns([1, 1])
    with col3:
        default_persona = BEAT_TO_PERSONA.get(beat, "BIZ-M-01")
        persona_options = ["Auto (beat-based)"] + list(PERSONA_BANK.keys())
        persona_choice = st.selectbox(
            "Persona override",
            persona_options,
            index=0,
            help=f"Auto selects {default_persona} for {beat}",
        )
        persona_id = None if persona_choice == "Auto (beat-based)" else persona_choice

        p = PERSONA_BANK.get(persona_id or default_persona)
        if p:
            st.caption(f"**{p.label}** — {p.description}")

        resolved_persona = persona_id or default_persona

        # ── Voice (ElevenLabs) ────────────────────────────────────────────────
        env_voice = config.resolve_voice_id(resolved_persona)
        voice_input = st.text_input(
            "ElevenLabs Voice ID",
            value=env_voice,
            placeholder="e.g. 21m00Tcm4TlvDq8ikWAM",
            help="Voice ID from elevenlabs.io/voice-library. Overrides .env setting.",
        )
        if voice_input.strip():
            st.session_state["voice_id"] = voice_input.strip()
            if voice_input.strip() != env_voice:
                st.caption("Voice: custom override")
            else:
                st.caption(f"Voice from .env: {voice_input.strip()[:20]}...")
        else:
            st.session_state["voice_id"] = env_voice
            if not env_voice:
                st.warning("No voice ID set. Add ELEVENLABS_VOICE_DEFAULT to .env or enter above.")

    with col4:
        prompts_only = st.checkbox(
            "Prompts only (no video generation)",
            value=False,
            help="Export a JSON prompt pack after script review. No ElevenLabs / Higgsfield calls.",
        )
        mode = "[PACK]" if prompts_only else "[FULL]"


    # ── Character image upload (Mode 1 + Mode 2) ──────────────────────────────
    if video_type in ("mode1", "mode2"):
        st.markdown("---")
        st.markdown("### Character")
        char_img_file = st.file_uploader(
            "Reference image (JPG/PNG)",
            type=["jpg", "jpeg", "png"],
            key="mode_char_img",
            label_visibility="collapsed",
        )
        if char_img_file:
            save_path = _save_uploaded_image(char_img_file, config.OUTPUT_DIR / "_avatars")
            st.session_state["avatar_image_path"] = save_path

        _cur_img = st.session_state.get("avatar_image_path") or ""
        if _cur_img and Path(_cur_img).exists():
            st.image(_cur_img, width=100, caption=Path(_cur_img).name)
        elif not char_img_file:
            st.warning("No character image set — upload one above. Avatar scenes will generate without reference.")

    if video_type in ("mode1", "mode2", "lipsync"):
        st.markdown("---")
        st.markdown("### Voice Ref (optional)")
        st.caption("Upload an MP3/WAV to lock voice consistency across all scenes. If not set, voice ref is extracted from Scene 1 after generation.")
        voice_ref_file = st.file_uploader(
            "Voice reference (MP3/WAV)",
            type=["mp3", "wav"],
            key="input_voice_ref",
            label_visibility="collapsed",
        )
        if voice_ref_file:
            _vr_tmp = config.OUTPUT_DIR / "_avatars"
            _vr_tmp.mkdir(exist_ok=True)
            _vr_save = str(_vr_tmp / voice_ref_file.name)
            with open(_vr_save, "wb") as f:
                f.write(voice_ref_file.read())
            st.session_state["voice_ref_upload_path"] = _vr_save
        _vr_cur = st.session_state.get("voice_ref_upload_path") or ""
        if _vr_cur and Path(_vr_cur).exists():
            st.caption(f"Active voice ref: {Path(_vr_cur).name}")

    # ── News source (mandatory) ────────────────────────────────────────────────
    st.markdown("---")
    st.markdown("### News source (required)")
    st.caption("Claude generates the script grounded in this article. Paste or fetch.")

    col_url, col_btn = st.columns([5, 1])
    with col_url:
        url_input = st.text_input(
            "Article URL",
            placeholder="https://economictimes.indiatimes.com/...",
            label_visibility="collapsed",
        )
    with col_btn:
        fetch_clicked = st.button("Fetch", use_container_width=True)

    if fetch_clicked:
        if not url_input.strip():
            st.warning("Enter a URL first.")
        else:
            with st.spinner("Fetching article via Jina Reader..."):
                try:
                    import re as _re
                    import requests as _requests

                    article_url = url_input.strip()
                    st.session_state["article_url"] = article_url

                    jina_url = f"https://r.jina.ai/{article_url}"
                    headers = {"Accept": "text/plain"}
                    if config.JINA_API_KEY:
                        headers["Authorization"] = f"Bearer {config.JINA_API_KEY}"
                    resp = _requests.get(jina_url, headers=headers, timeout=30)
                    resp.raise_for_status()
                    raw = resp.text.strip()

                    if raw:
                        clean = raw

                        # ── Step 1: Skip Jina's metadata header block ─────────────────────
                        # Jina always emits: Title / URL Source / Published Time / Markdown Content:
                        # Find "Markdown Content:" and take everything after it — most reliable.
                        mc_match = _re.search(r"^Markdown Content:\s*$", clean, _re.MULTILINE | _re.IGNORECASE)
                        if mc_match:
                            clean = clean[mc_match.end():]
                        else:
                            # Fallback: strip any line that looks like a key: value metadata line
                            # (short lines ending with something after a colon, before the article)
                            clean = _re.sub(
                                r"^.{0,40}:\s*.{0,120}$\n?", "", clean,
                                count=15, flags=_re.MULTILINE
                            )

                        # Strip lone section-header words (Summary, Contents, Overview)
                        clean = _re.sub(
                            r"^\s*(Summary|Contents?|Overview|Introduction)\s*$",
                            "", clean, flags=_re.MULTILINE | _re.IGNORECASE
                        )

                        # ── Step 2: Strip markdown image tags ────────────────────────────
                        clean = _re.sub(r"!\[[^\]]*\]\([^\)]*\)", "", clean)

                        # ── Step 3: Unwrap links → keep text only ─────────────────────────
                        clean = _re.sub(r"\[([^\]]+)\]\([^\)]+\)", r"\1", clean)

                        # ── Step 4: Strip bare URLs ───────────────────────────────────────
                        clean = _re.sub(r"https?://\S+", "", clean)

                        # ── Step 5: Remove markdown headers ──────────────────────────────
                        clean = _re.sub(r"^\s*#{1,6}\s+", "", clean, flags=_re.MULTILINE)

                        # ── Step 6: Remove bullet/list markers ────────────────────────────
                        clean = _re.sub(r"^\s*[*\-•]\s+", "", clean, flags=_re.MULTILINE)

                        # ── Step 7: Remove horizontal rules ──────────────────────────────
                        clean = _re.sub(r"^\s*[-=_]{3,}\s*$", "", clean, flags=_re.MULTILINE)

                        # ── Step 8: Strip known boilerplate lines (full-line match) ───────
                        noise_patterns = [
                            # Paywall / nav
                            r"subscribe\s*(now|today|to|for)?",
                            r"sign\s*up\s*(for|to)?",
                            r"log\s*in\s*(to|for)?",
                            r"already\s+a\s+subscriber",
                            r"read\s+more\s*:?",
                            r"also\s+read\s*:?",
                            r"advertisement",
                            r"sponsored\s+content",
                            r"share\s+this\s+article",
                            r"follow\s+us\s+on",
                            r"get\s+the\s+latest",
                            r"related\s+stories?",
                            r"copyright\s+\d{4}",
                            r"all\s+rights\s+reserved",
                            # Reuters-specific
                            r"reporting\s+by\b",
                            r"editing\s+by\b",
                            r"our\s+standards\s*:",
                            r"thomson\s+reuters",
                            r"trust\s+principles",
                            r"purchase\s+licens",
                            r"opens?\s+new\s+tab",
                            # Image captions (lines starting with "Chart showing", "Graph", "Table")
                            r"^(chart|graph|table|figure|image|photo)\s+(showing|of|depicting)",
                        ]
                        for pat in noise_patterns:
                            clean = _re.sub(
                                rf"^.*{pat}.*$", "", clean,
                                flags=_re.MULTILINE | _re.IGNORECASE
                            )

                        # ── Step 9: Final whitespace cleanup ─────────────────────────────
                        clean = _re.sub(r"[ \t]+", " ", clean)
                        clean = _re.sub(r"\n{3,}", "\n\n", clean)
                        clean = clean.strip()

                        # Pass to Groq for structured fact-pack summary
                        st.session_state["fetch_status"] = "summarizing"
                        st.session_state["fetch_error_msg"] = ""
                        st.session_state["news_content_edit"] = clean[:4000]  # temp store
                        st.session_state["_raw_article"] = clean[:6000]       # full for summarizer
                    else:
                        st.session_state["news_content_edit"] = ""
                        st.session_state["fetch_status"] = "empty"
                except Exception as e:
                    st.session_state["news_content_edit"] = ""
                    st.session_state["fetch_status"] = "error"
                    st.session_state["fetch_error_msg"] = str(e)

        # Run summarization outside the Jina spinner (separate step)
        if st.session_state.get("fetch_status") == "summarizing":
            raw_article = st.session_state.get("_raw_article", "")
            if raw_article:
                with st.spinner("Summarizing article with Groq — extracting key facts..."):
                    try:
                        _provider = st.session_state.get("llm_provider", "groq")
                        summary = summarize_article(raw_article, provider=_provider)
                        st.session_state["news_content_edit"] = summary
                        # Auto-detect beat and tone from the summarized article
                        from core.script_generator import detect_beat_and_tone
                        detected = detect_beat_and_tone(summary, provider=_provider)
                        st.session_state["auto_beat"] = detected["beat"]
                        st.session_state["auto_tone"] = detected["tone"]
                        st.session_state["fetch_status"] = "ok"
                    except Exception as e:
                        # Summarization failed — fall back to raw cleaned text, still usable
                        st.session_state["fetch_status"] = "ok"
                        st.session_state["fetch_error_msg"] = f"Summarization failed ({e}), using raw text."
            else:
                st.session_state["fetch_status"] = "empty"
            st.rerun()

    fetch_status = st.session_state.get("fetch_status")
    if fetch_status == "ok":
        char_count = len(st.session_state.get("news_content_edit", ""))
        fallback_warn = st.session_state.get("fetch_error_msg", "")
        if fallback_warn:
            st.warning(f"Summarization skipped: {fallback_warn}")
        st.success(f"Fetched + summarized — {char_count} chars ready as source material.")
    elif fetch_status == "empty":
        st.error("Could not extract article text from this URL. Paste manually below.")
    elif fetch_status == "error":
        err = st.session_state.get("fetch_error_msg", "")
        st.error(f"Fetch failed: {err}. Paste the article text manually below.")

    news_text = st.text_area(
        "Article text",
        key="news_content_edit",
        height=200,
        placeholder="Paste article text here, or use Fetch above...",
    )

    if news_text and news_text.strip():
        _detect_col, _ = st.columns([1, 3])
        with _detect_col:
            if st.button("Auto-detect beat & tone", key="detect_beat_tone"):
                with st.spinner("Detecting beat and tone..."):
                    try:
                        from core.script_generator import detect_beat_and_tone
                        _provider = st.session_state.get("llm_provider", "groq")
                        detected = detect_beat_and_tone(news_text.strip(), provider=_provider)
                        st.session_state["auto_beat"] = detected["beat"]
                        st.session_state["auto_tone"] = detected["tone"]
                        st.success(f"Beat: {detected['beat']} — Tone: {detected['tone']}")
                        st.rerun()
                    except Exception as e:
                        st.error(f"Detection failed: {e}")

    st.markdown("---")

    # Provider-aware API key check
    _active_provider = st.session_state.get("llm_provider", "groq")
    if _active_provider == "claude" and not config.ANTHROPIC_API_KEY:
        st.error("Claude selected but ANTHROPIC_API_KEY not set — add it to .env or switch to Groq.")
    elif _active_provider == "groq" and not config.GROQ_API_KEY:
        st.error("Groq selected but GROQ_API_KEY not set — add it to .env.")

    _api_key_ok = (
        (config.GROQ_API_KEY if _active_provider == "groq" else config.ANTHROPIC_API_KEY)
    )
    can_generate = bool(topic.strip()) and bool(news_text.strip()) and bool(_api_key_ok)
    if bool(topic.strip()) and bool(news_text.strip()) and not _api_key_ok:
        pass  # error already shown above
    elif not can_generate and topic.strip():
        st.warning("Add a news source before generating — paste text or fetch from URL.")

    if st.button("Generate Script", type="primary", disabled=not can_generate):
        _vt = st.session_state.get("video_type", "mode1")
        _scene_label = {"mode1": "5-scene", "mode2": "14-scene", "mode3": "micro-drama"}.get(_vt, "5-scene")
        with st.spinner(f"Generating {_scene_label} script..."):
            try:
                script_data = generate_script(
                    topic=topic.strip(),
                    beat=beat,
                    language=language,
                    tone=tone,
                    persona_id=persona_id,
                    news_content=news_text.strip(),
                    provider=st.session_state.get("llm_provider", "groq"),
                    video_type=st.session_state.get("video_type", "type1"),
                    include_text_cards=st.session_state.get("include_text_cards", True),
                    scene_sequence=st.session_state.get("scene_sequence", []),
                    video_duration=st.session_state.get("video_duration", 40),
                )
                # Drama has no flat scenes array — skip scenes_from_script
                if script_data.get("video_type") == "drama":
                    scenes = []
                else:
                    scenes = scenes_from_script(script_data)

                script_data["beat"] = beat  # store beat for animation fallback

                # Embed character image + voice ref paths so JSON is self-contained
                _char_img = st.session_state.get("avatar_image_path") or ""
                if _char_img:
                    script_data["character_image_path"] = _char_img
                _vr_embed = st.session_state.get("voice_ref_upload_path") or ""
                if _vr_embed:
                    script_data["voice_ref_path"] = _vr_embed

                # Save source + script to output folder immediately
                video_dir = config.OUTPUT_DIR / script_data["video_id"]
                video_dir.mkdir(parents=True, exist_ok=True)

                article_url = st.session_state.get("article_url", "")
                source_header = f"Source URL: {article_url}\n\n" if article_url else ""
                (video_dir / "source.txt").write_text(
                    source_header + news_text.strip(), encoding="utf-8"
                )
                (video_dir / "script.json").write_text(
                    json.dumps(script_data, indent=2, ensure_ascii=False),
                    encoding="utf-8",
                )

                st.session_state["script_data"] = script_data
                st.session_state["scenes"] = scenes
                st.session_state["video_id"] = script_data["video_id"]
                st.session_state["output_dir"] = str(video_dir)
                st.session_state["mode"] = mode
                st.session_state["screen"] = "review"
                st.rerun()

            except Exception as e:
                st.error(f"Script generation failed: {e}")


# ═══════════════════════════════════════════════════════════════════════════════
# ── Pre-flight validation ──────────────────────────────────────────────────────
def _preflight_checks(script: dict, scenes: list, is_type2: bool) -> list[str]:
    """
    Returns a list of blocking issues. Empty list = all clear.
    Called twice: once to display, once to gate the button — must be pure/fast.
    """
    issues = []
    env = config.check_env()

    # API keys
    if not env.get("elevenlabs"):
        issues.append("ElevenLabs API key missing — audio generation will fail.")

    # Higgsfield CLI
    import shutil
    _HIGGSFIELD_FALLBACK = r"C:\Users\HR 1\AppData\Roaming\fnm\node-versions\v20.20.2\installation\higgsfield.cmd"
    hf_available = shutil.which("higgsfield") or Path(_HIGGSFIELD_FALLBACK).exists()
    if not hf_available:
        issues.append("Higgsfield CLI not found — image/video generation will fail.")

    # Script fields
    if not script.get("video_id"):
        issues.append("Script missing video_id.")
    if not script.get("persona"):
        issues.append("Script missing persona — cannot resolve voice or avatar.")

    # Narration checks
    avatar_min = 430 if is_type2 else 100
    avatar_max = 500 if is_type2 else 165
    target_label = "430-450" if is_type2 else "~150"
    for s in scenes:
        if s.type != "AVATAR":
            continue
        cc = len(s.narration or "")
        if cc < avatar_min:
            issues.append(f"Scene {s.scene_number} narration too short ({cc} chars — target {target_label}). May cause audio to run short.")
        if cc > avatar_max:
            issues.append(f"Scene {s.scene_number} narration too long ({cc} chars — max {avatar_max}). Audio may get cut off.")

    # Image prompts — cutaway scenes must have one
    for s in scenes:
        if s.type == "CUTAWAY" and not (s.image_prompt or "").strip():
            issues.append(f"Scene {s.scene_number} (CUTAWAY) has no image prompt — Higgsfield will fail.")

    # Text cards (type1/type2) — must have both cards with non-empty lines
    text_cards = script.get("text_cards", [])
    if not is_type2 and len(text_cards) < 2:
        issues.append(f"Script has {len(text_cards)} text card(s) — expected 2.")
    for card in text_cards:
        lines = card.get("text_lines", [])
        if len(lines) < 2 or any(not l.strip() for l in lines):
            issues.append(f"Text card {card.get('card_id', '?')} has empty or missing text lines.")

    return issues


def _preflight_checks_drama(script: dict) -> list[str]:
    """Pre-flight checks specific to Type 3 (micro-drama) scripts."""
    issues = []
    env = config.check_env()
    import shutil
    _HIGGSFIELD_FALLBACK = r"C:\Users\HR 1\AppData\Roaming\fnm\node-versions\v20.20.2\installation\higgsfield.cmd"
    hf_available = shutil.which("higgsfield") or Path(_HIGGSFIELD_FALLBACK).exists()

    if not env.get("elevenlabs"):
        issues.append("ElevenLabs API key missing — audio generation will fail.")
    if not hf_available:
        issues.append("Higgsfield CLI not found — image/video generation will fail.")
    if not script.get("video_id"):
        issues.append("Script missing video_id.")
    if not script.get("beat"):
        issues.append("Script missing beat.")

    # Characters
    chars = script.get("characters", {})
    for char_id in ("char1", "char2"):
        char = chars.get(char_id, {})
        if not char:
            issues.append(f"{char_id} is missing from script.")
            continue
        if not (char.get("avatar_image_prompt") or "").strip():
            issues.append(f"{char_id} has no avatar image prompt.")
        if not (char.get("higgsfield_prompt") or "").strip():
            issues.append(f"{char_id} has no Higgsfield lipsync prompt.")

    # Takes — each char needs exactly 3, each with a non-empty script
    takes = script.get("takes", {})
    for char_id in ("char1", "char2"):
        char_takes = takes.get(char_id, [])
        if len(char_takes) != 3:
            issues.append(f"{char_id} has {len(char_takes)} take(s) — expected 3.")
        for t in char_takes:
            take_script = (t.get("script") or t.get("narration") or "").strip()
            t_num = t.get("take_number", "?")
            if not take_script:
                issues.append(f"{char_id} take {t_num} has no script/narration.")
            else:
                import re as _re
                spoken = _re.sub(r"\[.*?\]", "", take_script).strip()
                wc = len(spoken.split())
                dur = t.get("duration_seconds", 8)
                limit = 9 if dur <= 6 else 12
                if wc > limit:
                    issues.append(f"WARN:{char_id} take {t_num} is {wc} spoken words — max {limit} for {dur}s clip. Audio may cut off mid-sentence.")

    # Title card
    tc = script.get("title_card", {})
    if not (tc.get("hook_line") or "").strip():
        issues.append("Title card has no hook line.")

    # Text cards
    text_cards = script.get("text_cards", [])
    if len(text_cards) < 2:
        issues.append(f"Script has {len(text_cards)} text card(s) — expected 2.")
    for card in text_cards:
        lines = card.get("text_lines", [])
        if len(lines) < 2 or any(not l.strip() for l in lines):
            issues.append(f"Text card {card.get('card_id', '?')} has empty or missing text lines.")

    return issues


# SCREEN 2 — SCRIPT REVIEW
# ═══════════════════════════════════════════════════════════════════════════════
def screen_review():
    script = st.session_state["script_data"]
    video_type = st.session_state.get("video_type", "type1")

    # Mode 3 (drama) has its own dedicated review screen
    if video_type == "mode3" or script.get("video_type") == "mode3":
        screen_review_drama()
        return

    scenes: list[Scene] = st.session_state["scenes"]
    is_type2 = (video_type == "mode2")

    if st.button("← Back to input", key="review_back"):
        st.session_state["screen"] = "input"
        st.rerun()

    st.markdown(f"## Script Review — `{script['video_id']}`")

    col1, col2, col3 = st.columns(3)
    with col1:
        st.markdown(f"**Persona:** {script['persona']}")
        p = PERSONA_BANK.get(script["persona"])
        if p:
            st.caption(p.description)
    with col2:
        tmpl = STORY_TEMPLATES.get(script["template"])
        st.markdown(f"**Template:** {script['template']}")
        if tmpl:
            st.caption(tmpl.name)
    with col3:
        st.markdown(f"**Angle:** {script['angle']}")
        if is_type2:
            st.caption("Type 2 — 2 avatar (30s) + 10 cutaway (5s, 4:3, silent) + 2 text cards (4s)")

    st.markdown("---")

    # ── Character image preview (Mode 1 only) ────────────────────────────────
    if not is_type2:
        char_img = st.session_state.get("avatar_image_path") or ""
        if char_img and Path(char_img).exists():
            st.markdown("### Character")
            st.image(char_img, width=130, caption=Path(char_img).name)
            st.caption("This image is used as the reference for all AVATAR scene clips.")
        else:
            st.caption("No character image uploaded — AVATAR scenes will generate without image reference. Upload one in the sidebar.")
        _rv_vref = st.session_state.get("voice_ref_upload_path") or ""
        if _rv_vref and Path(_rv_vref).exists():
            st.caption(f"Voice ref: {Path(_rv_vref).name} — will be used for all scenes.")

    if is_type2:
        st.markdown("### Scenes — 2 avatar narrations + 10 infographic prompts")
        st.caption("Avatar scenes: edit narration (target 450 chars). Cutaway scenes: edit image + animation prompts only.")
    else:
        st.markdown("### Scenes — edit narration or prompts before generating")

    t1_text_cards = script.get("text_cards", []) if not is_type2 else []

    updated_scenes = []
    for scene in scenes:
        tag_class = "avatar" if scene.type == "AVATAR" else ("textcard" if scene.type == "TEXT_CARD" else "cutaway")
        tag_label = scene.type  # AVATAR / CUTAWAY / TEXT_CARD

        with st.expander(
            f"Scene {scene.scene_number} — {tag_label}  |  ~{scene.duration_seconds}s",
            expanded=True,
        ):
            st.markdown(
                f'<span class="tag tag-{tag_class}">{tag_label}</span>',
                unsafe_allow_html=True,
            )

            if scene.type == "TEXT_CARD":
                # Inline text card editor — used by Type 2 (TEXT_CARD scenes in scenes array)
                card_data = next(
                    (c for c in script.get("text_cards", []) if int(c.get("card_id", 0)) == (1 if scene.scene_number == 8 else 2)),
                    {}
                )
                ci = 0 if scene.scene_number == 8 else 1
                lines = card_data.get("text_lines", [])
                new_lines = []
                for i, line in enumerate(lines):
                    new_line = st.text_input(f"Line {i+1} (max 4 words)", value=line, key=f"tc_s{scene.scene_number}_line{i}")
                    new_lines.append(new_line)
                new_overlay = st.text_input("Overlay header (3-4 words)", value=card_data.get("overlay_text", ""), key=f"tc_s{scene.scene_number}_overlay")
                new_img = st.text_area("Image prompt (nano_banana_2)", value=card_data.get("image_prompt", scene.image_prompt or ""), key=f"tc_s{scene.scene_number}_img", height=90)
                if script.get("text_cards") and ci < len(script["text_cards"]):
                    script["text_cards"][ci]["text_lines"] = new_lines
                    script["text_cards"][ci]["overlay_text"] = new_overlay
                    script["text_cards"][ci]["image_prompt"] = new_img
                scene.image_prompt = new_img

            elif is_type2:
                if scene.type == "AVATAR":
                    char_count = len(scene.narration)
                    new_narration = st.text_area(
                        f"Narration ({char_count} chars — target 450)",
                        value=scene.narration,
                        key=f"narr_{scene.scene_number}",
                        height=120,
                    )
                    if char_count < 430:
                        st.warning(f"{char_count} chars — under target. May run short on 30s clip.")
                    elif char_count > 500:
                        st.warning(f"{char_count} chars — over 500. Audio may get cut.")
                    scene.narration = new_narration
                    _m2_avatar_prompt = _build_avatar_prompt(new_narration, getattr(scene, "background", "") or "")
                    with st.expander("Seedance prompt (editable)", expanded=False):
                        _m2ap = st.text_area(
                            "Full prompt sent to Seedance",
                            value=st.session_state.get(f"scene_prompt_override_{scene.scene_number}", _m2_avatar_prompt),
                            key=f"prompt_editor_{scene.scene_number}",
                            height=180,
                            label_visibility="collapsed",
                        )
                        st.session_state[f"scene_prompt_override_{scene.scene_number}"] = _m2ap
                else:
                    new_scene_desc = st.text_area(
                        "Scene description (visual concept)",
                        value=scene.scene_description or "",
                        key=f"desc_{scene.scene_number}",
                        height=70,
                    )
                    new_image_prompt = st.text_area(
                        "Image prompt",
                        value=scene.image_prompt or "",
                        key=f"img_{scene.scene_number}",
                        height=100,
                    )
                    new_anim_prompt = st.text_area(
                        "Animation prompt",
                        value=scene.animation_prompt or "",
                        key=f"anim_{scene.scene_number}",
                        height=70,
                    )
                    scene.scene_description = new_scene_desc or scene.scene_description
                    scene.image_prompt = new_image_prompt
                    scene.animation_prompt = new_anim_prompt or scene.animation_prompt
                    _m2_cut_prompt = " ".join(filter(None, [
                        new_scene_desc or "", new_image_prompt or "", new_anim_prompt or "",
                    ]))
                    with st.expander("Seedance prompt (editable)", expanded=False):
                        _m2cp = st.text_area(
                            "Full prompt sent to Seedance",
                            value=st.session_state.get(f"scene_prompt_override_{scene.scene_number}", _m2_cut_prompt),
                            key=f"prompt_editor_{scene.scene_number}",
                            height=160,
                            label_visibility="collapsed",
                        )
                        st.session_state[f"scene_prompt_override_{scene.scene_number}"] = _m2cp
            else:
                # Mode 1
                if scene.type == "AVATAR":
                    new_narration = st.text_area(
                        "Narration (spoken dialogue)",
                        value=scene.narration,
                        key=f"narr_{scene.scene_number}",
                        height=100,
                    )
                    scene.narration = new_narration

                    _avatar_prompt = _build_avatar_prompt(new_narration, getattr(scene, "background", "") or "")
                    with st.expander("Seedance prompt (editable)", expanded=False):
                        custom_prompt = st.text_area(
                            "Full prompt sent to Seedance",
                            value=st.session_state.get(f"scene_prompt_override_{scene.scene_number}", _avatar_prompt),
                            key=f"prompt_editor_{scene.scene_number}",
                            height=180,
                            label_visibility="collapsed",
                        )
                        st.session_state[f"scene_prompt_override_{scene.scene_number}"] = custom_prompt
                else:
                    # CUTAWAY — full fields
                    new_narration = st.text_area(
                        "Narration",
                        value=scene.narration,
                        key=f"narr_{scene.scene_number}",
                        height=80,
                    )
                    new_scene_desc = st.text_area(
                        "Scene description",
                        value=scene.scene_description or "",
                        key=f"desc_{scene.scene_number}",
                        height=70,
                    )
                    new_image_prompt = st.text_area(
                        "Image prompt",
                        value=scene.image_prompt or "",
                        key=f"img_{scene.scene_number}",
                        height=100,
                    )
                    new_anim_prompt = st.text_area(
                        "Animation prompt",
                        value=scene.animation_prompt or "",
                        key=f"anim_{scene.scene_number}",
                        height=70,
                    )
                    new_overlay = st.text_input(
                        "Overlay text",
                        value=scene.overlay_text or "",
                        key=f"overlay_{scene.scene_number}",
                    )
                    scene.narration = new_narration
                    scene.scene_description = new_scene_desc or scene.scene_description
                    scene.image_prompt = new_image_prompt
                    scene.animation_prompt = new_anim_prompt or scene.animation_prompt
                    scene.overlay_text = new_overlay or scene.overlay_text

                    _cutaway_prompt = " ".join(filter(None, [
                        new_scene_desc or scene.scene_description or "",
                        new_image_prompt or "",
                        new_anim_prompt or "",
                        f"Narration: {new_narration}" if new_narration else "",
                    ]))
                    with st.expander("Seedance prompt (editable)", expanded=False):
                        _cp = st.text_area(
                            "Full prompt sent to Seedance",
                            value=st.session_state.get(f"scene_prompt_override_{scene.scene_number}", _cutaway_prompt),
                            key=f"prompt_editor_{scene.scene_number}",
                            height=160,
                            label_visibility="collapsed",
                        )
                        st.session_state[f"scene_prompt_override_{scene.scene_number}"] = _cp

                # Per-scene generate button — prefer uploaded voice ref, fallback to scene 1 extract
                _m1_output_dir = Path(st.session_state.get("output_dir", "output"))
                _m1_clips_dir = _m1_output_dir / "clips"
                _m1_scene1_mp4 = _m1_clips_dir / "scene1_lipsync.mp4"
                _uploaded_vref = st.session_state.get("voice_ref_upload_path") or ""
                _m1_vref = Path(_uploaded_vref) if _uploaded_vref and Path(_uploaded_vref).exists() else None
                if _m1_vref is None and scene.scene_number > 1 and _m1_scene1_mp4.exists():
                    try:
                        _m1_vref = _extract_audio_from_clip(_m1_scene1_mp4)
                    except Exception:
                        pass

                existing_clip = next((
                    p for p in [
                        _m1_clips_dir / f"scene{scene.scene_number}_lipsync.mp4",
                        _m1_clips_dir / f"scene{scene.scene_number}_cutaway.mp4",
                        _m1_clips_dir / f"scene{scene.scene_number}_card.mp4",
                    ] if p.exists()
                ), None)

                if existing_clip:
                    st.caption(f"Clip exists: `{existing_clip.name}`")
                    st.video(existing_clip.read_bytes())

                if scene.scene_number > 1 and not _m1_scene1_mp4.exists():
                    st.caption("Generate Scene 1 first for voice continuity on this scene.")

                btn_label = f"Regenerate Scene {scene.scene_number}" if existing_clip else f"Generate Scene {scene.scene_number}"
                if existing_clip:
                    if st.button(btn_label, key=f"gen_m1_{scene.scene_number}"):
                        existing_clip.unlink(missing_ok=True)
                        # Also delete extracted audio ref so it gets re-extracted
                        _stale_mp3 = existing_clip.with_suffix(".mp3")
                        if _stale_mp3.exists():
                            _stale_mp3.unlink()
                        st.session_state["scenes"] = updated_scenes + [scene] + scenes[len(updated_scenes) + 1:]
                        st.session_state["script_data"] = script
                        _generate_single_mode1_clip(scene, _m1_output_dir, voice_ref=_m1_vref)
                elif st.button(btn_label, key=f"gen_m1_{scene.scene_number}"):
                    st.session_state["scenes"] = updated_scenes + [scene] + scenes[len(updated_scenes) + 1:]
                    st.session_state["script_data"] = script
                    _generate_single_mode1_clip(scene, _m1_output_dir, voice_ref=_m1_vref)

            updated_scenes.append(scene)

        # Type 1 — inject text cards inline after scene 2 (card 1) and scene 4 (card 2)
        if not is_type2 and t1_text_cards:
            inject_after = {2: 0, 4: 1}
            ci = inject_after.get(scene.scene_number)
            if ci is not None and ci < len(t1_text_cards):
                card = t1_text_cards[ci]
                card_id = int(card.get("card_id", ci + 1))
                purpose = card.get("purpose", f"Card {card_id}")
                with st.expander(f"TEXT CARD {card_id} — {purpose}  |  4s", expanded=True):
                    st.markdown('<span class="tag tag-textcard">TEXT CARD</span>', unsafe_allow_html=True)
                    lines = card.get("text_lines", [])
                    new_lines = []
                    for i, line in enumerate(lines):
                        new_line = st.text_input(f"Line {i+1} (max 4 words)", value=line, key=f"t1_card{card_id}_line{i}")
                        new_lines.append(new_line)
                    new_overlay = st.text_input("Overlay header (3-4 words)", value=card.get("overlay_text", ""), key=f"t1_card{card_id}_overlay")
                    new_img = st.text_area("Image prompt (nano_banana_2)", value=card.get("image_prompt", ""), key=f"t1_card{card_id}_img", height=90)
                    script["text_cards"][ci]["text_lines"] = new_lines
                    script["text_cards"][ci]["overlay_text"] = new_overlay
                    script["text_cards"][ci]["image_prompt"] = new_img

    st.session_state["scenes"] = updated_scenes
    if not is_type2:
        st.session_state["script_data"] = script

    st.session_state["script_data"] = script

    st.markdown("---")

    # ── Pre-flight checklist ───────────────────────────────────────────────────
    if st.session_state.get("mode", "[FULL]") != "[PACK]":
        st.markdown("### Pre-flight checklist")
        preflight_issues = _preflight_checks(script, updated_scenes, is_type2)
        blockers = [i for i in preflight_issues if not i.startswith("WARN:")]
        warnings = [i[5:] for i in preflight_issues if i.startswith("WARN:")]
        for issue in blockers:
            st.error(f"BLOCKED — {issue}")
        for issue in warnings:
            st.warning(f"WARNING — {issue}")
        if blockers:
            st.error("Fix the BLOCKED issues above before generating.")
        elif warnings:
            st.info("Warnings present — you can still generate, but review them.")
        else:
            st.success("All checks passed — ready to generate.")

    col_back, col_fwd = st.columns([1, 3])
    with col_back:
        if st.button("Back to input"):
            st.session_state["screen"] = "input"
            st.rerun()
    with col_fwd:
        mode = st.session_state.get("mode", "[FULL]")
        if mode == "[PACK]":
            if st.button("Export prompt pack JSON", type="primary"):
                _export_prompt_pack(script, updated_scenes)
        elif is_type2:
            preflight_ok = not any(not i.startswith("WARN:") for i in _preflight_checks(script, updated_scenes, is_type2))
            if st.button("Generate video", type="primary", disabled=not preflight_ok):
                st.session_state["screen"] = "progress"
                st.rerun()
        else:
            # Mode 1 — Generate All: scene 1 first (voice ref), then rest in async batches of 3
            if st.button("Generate All Scenes", type="primary"):
                m1_out = Path(st.session_state.get("output_dir", "output"))
                m1_out.mkdir(parents=True, exist_ok=True)
                _ga_uploaded = st.session_state.get("voice_ref_upload_path") or ""
                voice_ref: Path | None = Path(_ga_uploaded) if _ga_uploaded and Path(_ga_uploaded).exists() else None

                # Scene 1 always runs first — extract voice ref from it if not uploaded
                if updated_scenes:
                    dest = _generate_single_mode1_clip(updated_scenes[0], m1_out, voice_ref=voice_ref, force=True)
                    if dest and voice_ref is None:
                        try: voice_ref = _extract_audio_from_clip(dest)
                        except Exception: pass

                # Remaining scenes in parallel batches of 3
                remaining = updated_scenes[1:]
                placeholders = [st.empty() for _ in remaining]
                tasks = [
                    (lambda sc=sc, ph=ph: _generate_single_mode1_clip(sc, m1_out, voice_ref=voice_ref, force=True))
                    for sc, ph in zip(remaining, placeholders)
                ]
                _run_async_batch(tasks, max_workers=3)

                if st.session_state.get("include_text_cards", True):
                    _run_text_card_pipeline(script, m1_out, [], step_label="Text cards")
                st.success("All scenes generated.")


def _export_prompt_pack(script: dict, scenes: list[Scene]):
    """Downloads a JSON prompt pack — no API calls beyond Claude."""
    pack = {
        "video_id": script["video_id"],
        "persona": script["persona"],
        "template": script["template"],
        "angle": script["angle"],
        "scenes": [s.to_dict() for s in scenes],
    }
    st.download_button(
        "Download prompt pack JSON",
        data=json.dumps(pack, indent=2, ensure_ascii=False),
        file_name=f"{script['video_id']}_prompt_pack.json",
        mime="application/json",
    )


# ═══════════════════════════════════════════════════════════════════════════════
# SCREEN 3b — TYPE 2 GENERATION PIPELINE
# ═══════════════════════════════════════════════════════════════════════════════
def _screen_progress_type2(video_id: str, all_scenes: list[Scene]):
    """
    Type 2 split-screen pipeline:
    - Step 1: Audio for 2 AVATAR scenes only (30s each)
    - Step 2: HeyGen lipsync for 2 AVATAR scenes
    - Step 3: Generate 12 CUTAWAY images (4:3)
    - Step 4: Animate 12 CUTAWAY scenes (8s, Seedance)
    - No audio merge — cutaways are silent
    """
    st.caption("Split-screen pipeline — 2 avatar clips (30s) + 10 infographic clips (5s, 4:3) + 2 text cards (4s).")

    output_dir = Path(st.session_state["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)
    _copy_final_card(output_dir)
    log = st.session_state.get("generation_log", [])
    _anim_model = st.session_state.get("animation_model", "seedance_2_0_mini")

    def log_step(msg, ok=True):
        log.append(f"[{'OK' if ok else 'FAIL'}] {msg}")
        st.session_state["generation_log"] = log

    avatar_scenes  = [s for s in all_scenes if s.type == "AVATAR"]
    cutaway_scenes = [s for s in all_scenes if s.type == "CUTAWAY"]

    # ── Step 1: Audio for avatar scenes (30s cap) ─────────────────────────────
    with st.status(f"Step 1 — Generating {len(avatar_scenes)} avatar narrations (ElevenLabs)...", expanded=True) as s1:
        prog = st.progress(0)
        try:
            def cb(done, total): prog.progress(done / total, text=f"Audio {done}/{total}")
            avatar_scenes = generate_audio_for_scenes(
                avatar_scenes, output_dir,
                voice_id=st.session_state.get("voice_id"),
                persona_id=st.session_state.get("script_data", {}).get("persona"),
                audio_cap_seconds=config.TYPE2_AVATAR_DURATION_S,
                progress_callback=cb,
            )
            audio_by_num = {s.scene_number: s for s in avatar_scenes}
            for s in all_scenes:
                if s.scene_number in audio_by_num:
                    s.audio_path = audio_by_num[s.scene_number].audio_path
            log_step("Avatar audio complete")
            s1.update(label="Step 1 — Avatar audio done", state="complete")
        except Exception as e:
            log_step(f"Avatar audio failed: {e}", ok=False)
            s1.update(label=f"Step 1 — FAILED: {e}", state="error")
            st.error(str(e)); _show_log(log); return

    # ── Step 2: Seedance avatar clips with voice continuity ───────────────────
    with st.status(f"Step 2 — Generating {len(avatar_scenes)} avatar clips (Seedance)...", expanded=True) as s2:
        from core.higgsfield_cli import _extract_url
        from utils.cli_runner import run_higgsfield
        from utils.downloader import download_file
        clips_dir = output_dir / "clips"
        clips_dir.mkdir(exist_ok=True)
        avatar_img = st.session_state.get("avatar_image_path") or ""

        def _gen_t2_avatar(scene, voice_ref: Path | None) -> Path | None:
            dest = clips_dir / f"scene{scene.scene_number}_lipsync.mp4"
            if dest.exists():
                log_step(f"Scene {scene.scene_number} avatar already exists — skipping")
                scene.lipsync_video_path = str(dest)
                scene.final_video_path = str(dest)
                return dest
            narration = getattr(scene, "narration", "") or ""
            bg = getattr(scene, "background", "") or ""
            prompt = _build_avatar_prompt(narration, bg)
            cmd = [
                "generate", "create", st.session_state.get("animation_model", "seedance_2_0_mini"),
                "--prompt", prompt,
                "--aspect_ratio", "9:16",
                "--duration", str(config.HIGGSFIELD_VIDEO_DURATION),
                "--mode", config.HIGGSFIELD_VIDEO_MODE,
                "--generate_audio", "true",
                "--resolution", config.HIGGSFIELD_VIDEO_RESOLUTION,
            ]
            if avatar_img and Path(avatar_img).exists():
                cmd += ["--image", avatar_img]
            if voice_ref and voice_ref.exists():
                cmd += ["--audio", str(voice_ref)]
                log_step(f"Scene {scene.scene_number} using voice ref")
            try:
                cdn_url = _extract_url(run_higgsfield(cmd))
                download_file(cdn_url, dest)
                scene.lipsync_video_path = str(dest)
                scene.final_video_path = str(dest)
                log_step(f"Scene {scene.scene_number} avatar done")
                return dest
            except Exception as e:
                log_step(f"Scene {scene.scene_number} avatar failed: {e}", ok=False)
                st.warning(f"Scene {scene.scene_number} failed: {e}")
                return None

        try:
            _t2_uploaded = st.session_state.get("voice_ref_upload_path") or ""
            voice_ref_path: Path | None = Path(_t2_uploaded) if _t2_uploaded and Path(_t2_uploaded).exists() else None
            if avatar_scenes:
                # Scene 1 first — extract voice ref if not already uploaded
                first_dest = _gen_t2_avatar(avatar_scenes[0], voice_ref_path)
                if first_dest and voice_ref_path is None:
                    try:
                        voice_ref_path = _extract_audio_from_clip(first_dest)
                        log_step(f"Voice ref extracted from scene {avatar_scenes[0].scene_number}")
                    except Exception as ae:
                        log_step(f"Voice ref extraction failed: {ae}", ok=False)
                # Remaining in parallel
                remaining = avatar_scenes[1:]
                if remaining:
                    _run_async_batch(
                        [lambda sc=sc: _gen_t2_avatar(sc, voice_ref_path) for sc in remaining],
                        max_workers=3,
                    )
            s2.update(label="Step 2 — Avatar clips done", state="complete")
        except Exception as e:
            log_step(f"Avatar generation failed: {e}", ok=False)
            s2.update(label=f"Step 2 — FAILED: {e}", state="error")
            st.warning(str(e))

    # ── Step 3: Generate 12 cutaway images (4:3) ──────────────────────────────
    with st.status(f"Step 3 — Generating {len(cutaway_scenes)} infographic images (4:3)...", expanded=True) as s3:
        prog = st.progress(0)
        try:
            def cb(done, total): prog.progress(done / total, text=f"Image {done}/{total}")
            cutaway_scenes = generate_all_images(
                cutaway_scenes, output_dir,
                beat=st.session_state.get("script_data", {}).get("beat", "Finance"),
                aspect_ratio=config.TYPE2_IMAGE_ASPECT,
                progress_callback=cb,
            )
            log_step(f"Images complete — {len(cutaway_scenes)} at 4:3")
            s3.update(label="Step 3 — Images done", state="complete")
        except Exception as e:
            log_step(f"Image gen failed: {e}", ok=False)
            s3.update(label=f"Step 3 — FAILED: {e}", state="error")
            st.error(str(e)); _show_log(log); return

    # ── Step 4: Animate cutaway scenes ────────────────────────────────────────
    _anim_label = {"seedance_2_0_mini": "Seedance 2.0 Mini", "seedance_2_0": "Seedance 2.0 Fast"}.get(_anim_model, _anim_model)
    with st.status(f"Step 4 — Animating {len(cutaway_scenes)} infographic clips ({_anim_label}, 5s)...", expanded=True) as s4:
        prog = st.progress(0)
        try:
            def cb(done, total): prog.progress(done / total, text=f"Clip {done}/{total}")
            cutaway_scenes = animate_cutaway_scenes(
                cutaway_scenes, output_dir,
                beat=st.session_state.get("script_data", {}).get("beat", "Finance"),
                video_model=_anim_model,
                aspect_ratio=config.TYPE2_IMAGE_ASPECT,
                clip_duration=config.TYPE2_CLIP_DURATION,
                progress_callback=cb,
            )
            # Mark cutaway clips as final (no audio merge needed — silent)
            for s in cutaway_scenes:
                if s.cutaway_video_path:
                    s.final_video_path = s.cutaway_video_path
            log_step(f"Animation complete — {len(cutaway_scenes)} clips")
            s4.update(label=f"Step 4 — Animation done ({_anim_label})", state="complete")
        except Exception as e:
            log_step(f"Animation failed: {e}", ok=False)
            s4.update(label=f"Step 4 — FAILED: {e}", state="error")
            st.error(str(e)); _show_log(log); return

    # ── Step 5: Text cards ────────────────────────────────────────────────────
    if st.session_state.get("include_text_cards", True):
        _run_text_card_pipeline(st.session_state["script_data"], output_dir, log, step_label="Step 5")

    final_scenes = sorted(avatar_scenes + cutaway_scenes, key=lambda s: s.scene_number)
    _save_edit_timeline(final_scenes, output_dir, st.session_state["script_data"])
    st.session_state["final_scenes"] = final_scenes
    st.session_state["screen"] = "output"
    st.success("All steps complete.")
    st.rerun()


def _run_text_card_pipeline(script: dict, output_dir: Path, log: list, step_label: str = "Text cards"):
    """Generate image + Seedance animation for all text_cards in the script. Shared across type1, type2, drama."""
    from core.higgsfield_cli import generate_image, _extract_url
    from utils.cli_runner import run_higgsfield
    from utils.downloader import download_file

    text_cards = script.get("text_cards", [])
    if not text_cards:
        return

    cards_dir = output_dir / "cards"
    cards_dir.mkdir(exist_ok=True)
    total_steps = len(text_cards) * 2

    def log_step(msg, ok=True):
        log.append(f"[{'OK' if ok else 'FAIL'}] {msg}")

    with st.status(f"{step_label} — Generating {len(text_cards)} text cards (image + animation)...", expanded=True) as s_tc:
        prog = st.progress(0)
        done_count = 0
        try:
            for i, card in enumerate(text_cards):
                card_id  = card.get("card_id", i + 1)
                img_dest = cards_dir / f"textcard_{card_id}.jpg"
                mp4_dest = cards_dir / f"textcard_{card_id}.mp4"

                # Image
                if not img_dest.exists():
                    img_prompt = _build_card_image_prompt(card)
                    if not card.get("image_prompt", "").strip():
                        log_step(f"textcard_{card_id} missing image_prompt — skipping", ok=False)
                        prog.progress((i * 2 + 2) / total_steps)
                        continue
                    try:
                        resp    = generate_image(img_prompt, aspect_ratio="9:16")
                        cdn_url = _extract_url(resp)
                        download_file(cdn_url, img_dest)
                        log_step(f"textcard_{card_id} image saved")
                    except Exception as e:
                        log_step(f"textcard_{card_id} image failed: {e}", ok=False)
                        st.warning(f"Card {card_id} image failed: {e}")
                        prog.progress((i * 2 + 2) / total_steps)
                        continue
                else:
                    log_step(f"textcard_{card_id} image already exists — skipping")
                done_count += 1
                prog.progress((i * 2 + 1) / total_steps)

                # Animation
                if not mp4_dest.exists():
                    overlay   = card.get("overlay_text", "").strip()
                    lines     = card.get("text_lines", card.get("lines", []))
                    lines_str = " / ".join(l for l in lines if l.strip())
                    text_ref  = f'Header: "{overlay}". ' if overlay else ""
                    text_ref += f'Lines: {lines_str}.' if lines_str else ""
                    full_anim_prompt = f"{_CARD_ANIM_PROMPT} {text_ref}".strip()
                    try:
                        cmd = [
                            "generate", "create", st.session_state.get("animation_model", "seedance_2_0_mini"),
                            "--prompt", full_anim_prompt,
                            "--image", str(img_dest),
                            "--aspect_ratio", "9:16",
                            "--duration", "4",
                            "--mode", "fast",
                            "--generate_audio", "true",
                            "--resolution", "480p",
                        ]
                        resp    = run_higgsfield(cmd)
                        cdn_url = _extract_url(resp)
                        download_file(cdn_url, mp4_dest)
                        log_step(f"textcard_{card_id} animation saved")
                    except Exception as e:
                        log_step(f"textcard_{card_id} animation failed: {e}", ok=False)
                        st.warning(f"Card {card_id} animation failed: {e}")
                else:
                    log_step(f"textcard_{card_id} animation already exists — skipping")

                prog.progress((i * 2 + 2) / total_steps)

            s_tc.update(label=f"{step_label} — Text cards done ({done_count}/{len(text_cards)})", state="complete")
        except Exception as e:
            log_step(f"Text card pipeline failed: {e}", ok=False)
            s_tc.update(label=f"{step_label} — FAILED: {e}", state="error")
            st.warning(f"Text cards failed (non-fatal): {e}")


def _generate_single_char_image(script: dict, char_id: str):
    """Generate avatar image for one character and show result inline."""
    from core.higgsfield_cli import generate_image, _extract_url
    from utils.downloader import download_file

    output_dir  = Path(st.session_state.get("output_dir", "output"))
    images_dir  = output_dir / "images"
    images_dir.mkdir(parents=True, exist_ok=True)

    dest        = images_dir / f"{char_id}_avatar.jpg"
    img_prompt  = script.get("characters", {}).get(char_id, {}).get("avatar_image_prompt", "")

    if not img_prompt:
        st.error(f"{char_id}: avatar_image_prompt is empty — fill it in first.")
        return

    with st.spinner(f"Generating {char_id} avatar image..."):
        try:
            response = generate_image(img_prompt, aspect_ratio="9:16")
            cdn_url  = _extract_url(response)
            download_file(cdn_url, dest)
            st.success(f"{char_id} avatar saved")
            st.image(str(dest), width=200)
        except Exception as e:
            st.error(f"{char_id} image failed: {e}")



_CARD_ANIM_PROMPT = (
    "The text already present in the image must remain fully visible and legible throughout the entire video. "
    "Animate the text with a typewriter reveal effect from left to right — each word or character appears one by one. "
    "Very subtle slow push-in on the background image, no camera shake. "
    "Cinematic, calm, deliberate pace. "
    "Preserve all existing text exactly as shown. Do not add new text, subtitles, logos, watermarks, or UI elements."
)


def _generate_title_card_image(script: dict):
    """Generate nano_banana_2 image for the title card with hook_line baked into prompt."""
    from core.higgsfield_cli import generate_image, _extract_url
    from utils.downloader import download_file

    output_dir = Path(st.session_state.get("output_dir", "output"))
    cards_dir  = output_dir / "cards"
    cards_dir.mkdir(parents=True, exist_ok=True)

    tc         = script.get("title_card", {})
    hook       = tc.get("hook_line", "").strip().upper()
    base       = tc.get("image_prompt", "").rstrip(". ")
    img_dest   = cards_dir / "title_card.jpg"

    if not base:
        st.error("Title card: image_prompt is empty.")
        return

    text_instruction = (
        f'The image must prominently display the bold white text "{hook}" centered on screen. '
        "Large, clean, editorial sans-serif. Pure black background with minimal symbolic element. "
        "Vertical 9:16 format."
    ) if hook else ""
    full_prompt = f"{base}. {text_instruction}".strip() if text_instruction else base

    with st.spinner("Generating title card image..."):
        try:
            response = generate_image(full_prompt, aspect_ratio="9:16")
            cdn_url  = _extract_url(response)
            download_file(cdn_url, img_dest)
            st.success("Title card image saved")
            st.image(str(img_dest), width=200)
        except Exception as e:
            st.error(f"Title card image failed: {e}")



def _build_card_image_prompt(card: dict) -> str:
    """Build nano_banana_2 prompt that includes the card text visually."""
    base        = card.get("image_prompt", "").rstrip(". ")
    overlay     = card.get("overlay_text", "").strip().upper()
    lines       = card.get("text_lines", card.get("lines", []))

    text_parts = []
    if overlay:
        text_parts.append(f'bold headline text "{overlay}"')
    for line in lines:
        if line.strip():
            text_parts.append(f'"{line.strip()}"')

    if text_parts:
        text_instruction = (
            "The image must prominently display the following text overlaid on the visual: "
            + ", ".join(text_parts)
            + ". Text is clean, large, white, legible, editorial sans-serif style. "
            "Dark semi-transparent scrim behind text for readability. Vertical 9:16 format."
        )
        return f"{base}. {text_instruction}"
    return base


def _generate_card_image_only(script: dict, card_index: int, card_id: int):
    """Generate nano_banana_2 image for one text card with text baked into prompt."""
    from core.higgsfield_cli import generate_image, _extract_url
    from utils.downloader import download_file

    output_dir = Path(st.session_state.get("output_dir", "output"))
    cards_dir  = output_dir / "cards"
    cards_dir.mkdir(parents=True, exist_ok=True)

    card       = script.get("text_cards", [])[card_index]
    img_prompt = _build_card_image_prompt(card)
    img_dest   = cards_dir / f"textcard_{card_id}.jpg"

    if not card.get("image_prompt", "").strip():
        st.error(f"Card {card_id}: image_prompt is empty.")
        return

    with st.spinner(f"Generating card {card_id} image (text included)..."):
        try:
            response = generate_image(img_prompt, aspect_ratio="9:16")
            cdn_url  = _extract_url(response)
            download_file(cdn_url, img_dest)
            st.success(f"Card {card_id} image saved")
            st.image(str(img_dest), width=200)
        except Exception as e:
            st.error(f"Card {card_id} image failed: {e}")


def _animate_card_only(script: dict, card_index: int, card_id: int):
    """Animate existing text card image with Seedance 2.0 fast, 4s."""
    from core.higgsfield_cli import _extract_url
    from utils.cli_runner import run_higgsfield
    from utils.downloader import download_file

    output_dir = Path(st.session_state.get("output_dir", "output"))
    cards_dir  = output_dir / "cards"
    img_dest   = cards_dir / f"textcard_{card_id}.jpg"
    mp4_dest   = cards_dir / f"textcard_{card_id}.mp4"

    if not img_dest.exists():
        st.error(f"Card {card_id}: generate the image first.")
        return

    card      = script.get("text_cards", [])[card_index]
    overlay   = card.get("overlay_text", "").strip()
    lines     = card.get("text_lines", card.get("lines", []))
    lines_str = " / ".join(l for l in lines if l.strip())
    text_ref  = f'Header: "{overlay}". ' if overlay else ""
    text_ref += f'Lines: {lines_str}.' if lines_str else ""
    full_anim_prompt = f"{_CARD_ANIM_PROMPT} {text_ref}".strip()

    with st.spinner(f"Animating card {card_id} (Seedance 4s, 480p)..."):
        try:
            cmd = [
                "generate", "create", st.session_state.get("animation_model", "seedance_2_0_mini"),
                "--prompt", full_anim_prompt,
                "--image", str(img_dest),
                "--aspect_ratio", "9:16",
                "--duration", "4",
                "--mode", "fast",
                "--generate_audio", "true",
                "--resolution", "480p",
            ]
            response = run_higgsfield(cmd)
            cdn_url  = _extract_url(response)
            download_file(cdn_url, mp4_dest)
            st.success(f"Card {card_id} done")
            st.video(mp4_dest.read_bytes())
        except Exception as e:
            st.error(f"Card {card_id} animation failed: {e}")


def _build_avatar_prompt(narration: str, background: str = "", scene_description: str = "") -> str:
    """Single source of truth for all AVATAR Seedance prompts."""
    setting = (background.strip() or scene_description.strip()) or (
        "sitting at a wooden desk in a home office or study. "
        "Warm soft ambient indoor lighting. Slightly blurred bookshelf or wall decor in background."
    )
    dialogue_block = f"The person is saying: '{narration}'" if narration else ""
    return " ".join(filter(None, [
        f"The person from the reference image is {setting}",
        "Chest-up medium close-up, eye-level camera, locked frame.",
        "The person is speaking naturally and directly to camera, mouth moving with real human speech rhythm.",
        "Voice sounds natural and human — Indian accent, conversational, warm, not robotic, not AI-generated.",
        "Realistic breathing pauses, natural micro-expressions, occasional natural blinks.",
        dialogue_block,
        "No gestures. No body movement. No zoom. No cuts. No scene change.",
        "No captions, no subtitles, no text, no watermark, no logos anywhere in frame.",
    ]))


def _run_async_batch(tasks: list, max_workers: int = 3) -> list:
    """Run a list of callables in parallel, max_workers at a time. Returns results in order."""
    # ponytail: simple ThreadPoolExecutor — Streamlit widget calls must use pre-created placeholders
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = [ex.submit(fn) for fn in tasks]
        return [f.result() for f in futures]


def _generate_single_mode1_clip(scene: Scene, output_dir: Path, voice_ref: Path = None, force: bool = False):
    """
    Generate one Mode 1 scene clip via Seedance 2.0 fast.
    Narration is embedded in prompt. --generate_audio true handles audio.
    voice_ref: mp3 extracted from the first generated clip — passed as --audio for voice continuity.
    """
    import re as _re
    from core.higgsfield_cli import _extract_url
    from utils.cli_runner import run_higgsfield
    from utils.downloader import download_file

    clips_dir = output_dir / "clips"
    clips_dir.mkdir(parents=True, exist_ok=True)

    n = scene.scene_number
    stype = scene.type

    if stype == "AVATAR":
        dest = clips_dir / f"scene{n}_lipsync.mp4"
    elif stype == "CUTAWAY":
        dest = clips_dir / f"scene{n}_cutaway.mp4"
    else:
        dest = clips_dir / f"scene{n}_card.mp4"

    if force and dest.exists():
        dest.unlink()
        _stale = dest.with_suffix(".mp3")
        if _stale.exists():
            _stale.unlink()

    narration = _re.sub(r"\[.*?\]", "", scene.narration or "").strip()
    scene_desc = (scene.scene_description or scene.image_prompt or "").strip()
    anim_prompt = (scene.animation_prompt or "").strip()

    if stype == "AVATAR":
        override = st.session_state.get(f"scene_prompt_override_{n}", "").strip()
        if override:
            full_prompt = override
        else:
            full_prompt = _build_avatar_prompt(narration, getattr(scene, "background", "") or "")
    else:
        override = st.session_state.get(f"scene_prompt_override_{n}", "").strip()
        if override:
            full_prompt = override
        else:
            parts = []
            if scene_desc:
                parts.append(scene_desc)
            if anim_prompt:
                parts.append(anim_prompt)
            if narration:
                parts.append(f"Narration: {narration}")
            full_prompt = " ".join(parts) or scene_desc or narration

    duration = min(int(getattr(scene, "duration_seconds", 8) or 8), 8)

    cmd = [
        "generate", "create", st.session_state.get("animation_model", "seedance_2_0_mini"),
        "--prompt", full_prompt,
        "--aspect_ratio", "9:16",
        "--duration", str(duration),
        "--mode", config.HIGGSFIELD_VIDEO_MODE,
        "--generate_audio", "true",
        "--resolution", config.HIGGSFIELD_VIDEO_RESOLUTION,
    ]

    char_img = st.session_state.get("avatar_image_path") or ""
    if stype == "AVATAR" and char_img and Path(char_img).exists():
        cmd += ["--image", char_img]

    if stype == "CUTAWAY" and scene.image_path and Path(scene.image_path).exists():
        cmd += ["--image", scene.image_path]

    if voice_ref and voice_ref.exists():
        cmd += ["--audio", str(voice_ref)]

    label = f"Scene {n} ({stype})" + (" — voice ref" if voice_ref else "")
    with st.spinner(f"Generating {label}..."):
        try:
            response = run_higgsfield(cmd)
            cdn_url = _extract_url(response)
            download_file(cdn_url, dest)
            st.success(f"Scene {n} done")
            st.video(dest.read_bytes())
            return dest
        except Exception as e:
            st.error(f"Scene {n} failed: {e}")
            return None


def _copy_final_card(output_dir: Path) -> None:
    """Copy AMPM-FINAL_CARD.mp4 into the output folder if it exists and isn't already there."""
    import shutil
    src = config.AMPM_FINAL_CARD
    dst = output_dir / "AMPM-FINAL_CARD.mp4"
    if src.exists() and not dst.exists():
        shutil.copy2(src, dst)


def _anim_mode_flags() -> list:
    # seedance_2_0_mini does not support --mode; only add for seedance_2_0
    return ["--mode", "fast"] if st.session_state.get("animation_model", "seedance_2_0_mini") == "seedance_2_0" else []


def _extract_audio_from_clip(mp4_path: Path) -> Path:
    """Extract audio track from a clip as .mp3 using ffmpeg. Returns path to audio file."""
    import subprocess
    audio_path = mp4_path.with_suffix(".mp3")
    if audio_path.exists():
        return audio_path
    result = subprocess.run(
        ["ffmpeg", "-y", "-i", str(mp4_path), "-vn", "-acodec", "mp3", str(audio_path)],
        capture_output=True, text=True
    )
    if result.returncode != 0:
        raise RuntimeError(f"ffmpeg audio extraction failed: {result.stderr.strip()}")
    return audio_path


def _generate_single_drama_clip(script: dict, char_id: str, take: dict, t_num: int, voice_ref: Path = None):
    """Generate a single Seedance clip for one take and show result inline.
    voice_ref: path to an mp3 extracted from Take 1 of this character — passed as --audio for voice consistency.
    """
    import re as _re
    from core.higgsfield_cli import _extract_url
    from utils.cli_runner import run_higgsfield
    from utils.downloader import download_file

    output_dir = Path(st.session_state.get("output_dir", "output"))
    clips_dir  = output_dir / "clips"
    images_dir = output_dir / "images"
    clips_dir.mkdir(parents=True, exist_ok=True)

    label = f"{char_id}_take{t_num}"
    dest  = clips_dir / f"{label}.mp4"

    chars        = script.get("characters", {})
    char_data    = chars.get(char_id, {})
    base_prompt  = char_data.get("higgsfield_prompt", "")
    base_prompt  = _re.sub(r"Locked [^.]+\.", "", base_prompt).strip()
    clean_script = _re.sub(r"\[.*?\]", "", take.get("script", "")).strip()
    camera_angle = take.get("camera_angle", "").strip()
    voice_prompt = char_data.get("voice_prompt", "").strip()
    voice_block  = f"Voice: {voice_prompt}" if voice_prompt else ""
    full_prompt  = " ".join(filter(None, [
        camera_angle + "," if camera_angle else "",
        base_prompt,
        voice_block,
        f"Dialogue: {clean_script}" if clean_script else "",
    ]))
    # Drama take durations are fixed by structure — ignore LLM's duration_seconds
    _DRAMA_DURATION = {("char1", 1): 6, ("char1", 2): 8, ("char1", 3): 6,
                       ("char2", 1): 8, ("char2", 2): 8, ("char2", 3): 6}
    duration = _DRAMA_DURATION.get((char_id, t_num), int(take.get("duration_seconds", 8)))

    avatar_img = images_dir / f"{char_id}_avatar.jpg"

    cmd = [
        "generate", "create", st.session_state.get("animation_model", "seedance_2_0_mini"),
        "--prompt", full_prompt,
        "--aspect_ratio", "9:16",
        "--duration", str(duration),
        "--mode", config.HIGGSFIELD_VIDEO_MODE,
        "--generate_audio", "true",
        "--resolution", config.HIGGSFIELD_VIDEO_RESOLUTION,
    ]
    if avatar_img.exists():
        cmd += ["--image", str(avatar_img)]
    if voice_ref and voice_ref.exists():
        cmd += ["--audio", str(voice_ref)]

    with st.spinner(f"Generating {label}" + (" (voice ref from take 1)" if voice_ref else "") + "..."):
        try:
            response = run_higgsfield(cmd)
            cdn_url  = _extract_url(response)
            download_file(cdn_url, dest)
            st.success(f"{label} done")
            st.video(dest.read_bytes())
        except Exception as e:
            st.error(f"{label} failed: {e}")


def _render_text_card(card: dict, dest: Path) -> None:
    """
    Renders a text card MP4 using PIL (frame composition) + ffmpeg (animation + duration).

    card_id 1  — typewriter: each line appears 0.4s apart, hold 3s, cut in/out
    card_id 2  — fade in 0.3s, hold 5s, fade out 0.3s
    card_id 3  — final brand card: fade in 0.3s, hold to end
    """
    import subprocess
    from PIL import Image, ImageDraw, ImageFont

    W, H = 1080, 1920  # 9:16
    card_id = card.get("card_id", 1)
    lines = card.get("lines", [])
    duration = card.get("duration_seconds", 6)
    animation = card.get("animation", "")

    # ── Font setup ────────────────────────────────────────────────────────────
    font_dir = Path(__file__).parent / "assets" / "fonts"

    def _load_font(size: int, bold: bool = True, italic: bool = False) -> ImageFont.FreeTypeFont:
        candidates = []
        if italic and bold:
            candidates += ["GeistMono-Bold.ttf", "Geist-Bold.ttf"]
        elif bold:
            candidates += ["Geist-Bold.ttf", "GeistMono-Bold.ttf"]
        else:
            candidates += ["Geist-Regular.ttf", "GeistMono-Regular.ttf"]
        # System fallbacks
        candidates += ["arialbd.ttf", "arial.ttf", "DejaVuSans-Bold.ttf", "DejaVuSans.ttf"]
        for name in candidates:
            for search in [font_dir, Path("C:/Windows/Fonts"), Path("/usr/share/fonts/truetype/dejavu")]:
                p = search / name
                if p.exists():
                    return ImageFont.truetype(str(p), size)
        return ImageFont.load_default()

    # ── Render a single frame with all lines visible ──────────────────────────
    def _make_frame(visible_lines: list[tuple[str, bool, bool]]) -> Image.Image:
        """visible_lines: list of (text, is_bold, is_italic)"""
        img = Image.new("RGB", (W, H), (0, 0, 0))
        draw = ImageDraw.Draw(img)

        line_spacing = 90
        total_h = len(visible_lines) * line_spacing
        y = (H - total_h) // 2

        for text, bold, italic in visible_lines:
            if card_id == 3:
                # Brand card: smaller sizes, centered bottom half
                font = _load_font(52 if text.startswith("AM:PM") else 38 if bold else 28, bold=bold, italic=italic)
            else:
                font = _load_font(64 if bold else 48, bold=bold, italic=italic)

            bbox = draw.textbbox((0, 0), text, font=font)
            tw = bbox[2] - bbox[0]
            draw.text(((W - tw) // 2, y), text, font=font, fill=(255, 255, 255))
            y += line_spacing

        return img

    # ── Determine line styles ─────────────────────────────────────────────────
    styled_lines: list[tuple[str, bool, bool]] = []
    for i, line in enumerate(lines):
        is_italic = (card_id == 2 and i == len(lines) - 1)  # card 2 line 3 is italic
        is_bold = not is_italic
        styled_lines.append((line, is_bold, is_italic))

    tmp = dest.parent / f"_tmp_{dest.stem}"
    tmp.mkdir(exist_ok=True)

    try:
        if card_id == 1 or "typewriter" in animation.lower():
            # Typewriter: generate one PNG per line-reveal state, concat via ffmpeg concat demuxer
            frame_paths = []
            fps = 30
            stagger_frames = int(0.4 * fps)  # 12 frames between lines
            hold_frames = int(3 * fps)        # 90 frames hold at full

            # Blank opening frame (1 frame — cuts in immediately)
            blank = Image.new("RGB", (W, H), (0, 0, 0))
            blank_path = tmp / "blank.png"
            blank.save(blank_path)

            for n in range(1, len(styled_lines) + 1):
                frame = _make_frame(styled_lines[:n])
                p = tmp / f"state_{n:02d}.png"
                frame.save(p)
                frame_paths.append((p, stagger_frames if n < len(styled_lines) else hold_frames))

            # Write concat file
            concat_txt = tmp / "concat.txt"
            with open(concat_txt, "w") as f:
                f.write(f"file '{blank_path.as_posix()}'\nduration {1/fps:.4f}\n")
                for img_path, n_frames in frame_paths:
                    f.write(f"file '{img_path.as_posix()}'\nduration {n_frames/fps:.4f}\n")
                # ffmpeg concat needs a final file entry with no duration
                f.write(f"file '{frame_paths[-1][0].as_posix()}'\n")

            subprocess.run([
                "ffmpeg", "-y",
                "-f", "concat", "-safe", "0",
                "-i", str(concat_txt),
                "-vf", f"scale={W}:{H},format=yuv420p",
                "-r", str(fps),
                "-c:v", "libx264", "-crf", "18", "-preset", "fast",
                "-t", str(duration),
                str(dest),
            ], check=True, capture_output=True, timeout=60)

        else:
            # Fade in / fade out — render single full frame, apply ffmpeg fade filters
            frame = _make_frame(styled_lines)
            frame_path = tmp / "frame.png"
            frame.save(frame_path)

            fade_in_d = 0.3
            fade_out_d = 0.3 if "fade out" in animation.lower() else 0.0
            fade_out_start = duration - fade_out_d if fade_out_d else duration

            vf_parts = [f"fade=in:st=0:d={fade_in_d}"]
            if fade_out_d:
                vf_parts.append(f"fade=out:st={fade_out_start}:d={fade_out_d}")
            vf_parts.append(f"scale={W}:{H},format=yuv420p")

            subprocess.run([
                "ffmpeg", "-y",
                "-loop", "1",
                "-i", str(frame_path),
                "-vf", ",".join(vf_parts),
                "-c:v", "libx264", "-crf", "18", "-preset", "fast",
                "-t", str(duration),
                "-r", "30",
                str(dest),
            ], check=True, capture_output=True, timeout=60)
    finally:
        import shutil
        shutil.rmtree(tmp, ignore_errors=True)


# ═══════════════════════════════════════════════════════════════════════════════
# SCREEN 3 — GENERATION PROGRESS
# ═══════════════════════════════════════════════════════════════════════════════
def _screen_progress_drama(video_id: str, script: dict):
    """
    Drama pipeline:
    Step 1 — Generate 2 character avatar images (Higgsfield nano_banana_2)
    Step 2 — Generate 5 character clips (Seedance 2.0 — video + voice in one call)
    Step 3 — Generate 3 text card MP4s (PIL + ffmpeg)
    No ElevenLabs. No HeyGen. No cutaways.
    """
    st.caption("Micro-drama pipeline — 2 avatar images + 5 character clips + 3 text cards.")

    output_dir = Path(st.session_state["output_dir"])
    output_dir.mkdir(parents=True, exist_ok=True)
    _copy_final_card(output_dir)
    log = st.session_state.get("generation_log", [])

    def log_step(msg, ok=True):
        log.append(f"[{'OK' if ok else 'FAIL'}] {msg}")
        st.session_state["generation_log"] = log

    chars   = script.get("characters", {})
    takes   = script.get("takes", {})
    beat    = script.get("beat", "Politics")

    # Build a flat ordered list of all takes for voice + lipsync steps
    # Format: (char_id, take_dict, label)
    all_takes = []
    for t in takes.get("char1", []):
        all_takes.append(("char1", t, f"char1_take{t['take_number']}"))
    for t in takes.get("char2", []):
        all_takes.append(("char2", t, f"char2_take{t['take_number']}"))

    images_dir = output_dir / "images"
    clips_dir  = output_dir / "clips"
    images_dir.mkdir(exist_ok=True)
    clips_dir.mkdir(exist_ok=True)

    char_image_paths = {}
    take_lipsync_paths = {}

    # ── Step 1: Resolve character avatar images ───────────────────────────────
    # Priority: uploaded avatar_image_path > already on disk > generate via nano_banana_2
    uploaded_avatar = st.session_state.get("avatar_image_path") or ""
    with st.status("Step 1 — Resolving character avatar images...", expanded=True) as s1:
        from core.higgsfield_cli import generate_image as _gen_img, _extract_url as _ext_url
        from utils.downloader import download_file as _dl_file
        import shutil as _shutil

        def _resolve_char_image(char_id, char_data):
            dest = images_dir / f"{char_id}_avatar.jpg"
            if uploaded_avatar and Path(uploaded_avatar).exists() and char_id == "char1":
                _shutil.copy2(uploaded_avatar, dest)
                log_step(f"{char_id} using uploaded avatar image")
                return char_id, str(dest), None
            if dest.exists():
                log_step(f"{char_id} image already exists — skipping")
                return char_id, str(dest), None
            img_prompt = char_data.get("avatar_image_prompt", "")
            if not img_prompt:
                log_step(f"{char_id} missing avatar_image_prompt — skipping", ok=False)
                return char_id, None, char_id
            try:
                cdn_url = _ext_url(_gen_img(img_prompt, aspect_ratio="9:16"))
                _dl_file(cdn_url, dest)
                log_step(f"{char_id} avatar image generated -> {dest.name}")
                return char_id, str(dest), None
            except Exception as e:
                log_step(f"{char_id} image failed: {e}", ok=False)
                return char_id, None, char_id

        char_items = list(chars.items())
        results = _run_async_batch(
            [lambda cid=cid, cd=cd: _resolve_char_image(cid, cd) for cid, cd in char_items],
            max_workers=3,
        )
        failed_images = []
        for char_id, img_path, failed in results:
            if img_path:
                char_image_paths[char_id] = img_path
            if failed:
                failed_images.append(failed)

        if failed_images:
            s1.update(label=f"Step 1 — Images done (failed: {failed_images})", state="complete")
        else:
            s1.update(label="Step 1 — Avatar images resolved", state="complete")

    # ── Step 2: Generate character clips (Seedance 2.0 — video + voice in one) ──
    # Take 1 of each char runs first (parallel across chars) → voice refs extracted
    # → remaining takes run in a single parallel batch.
    with st.status(f"Step 2 — Generating {len(all_takes)} character clips (Seedance 2.0)...", expanded=True) as s3:
        try:
            import re as _re
            from core.higgsfield_cli import _extract_url
            from utils.cli_runner import run_higgsfield
            from utils.downloader import download_file

            voice_refs: dict = {}

            def _gen_drama_take(char_id, take, label, voice_ref: Path | None) -> tuple:
                dest = clips_dir / f"{label}.mp4"
                if dest.exists():
                    log_step(f"{label} already exists — skipping")
                    return label, str(dest)
                char_data    = chars.get(char_id, {})
                base_prompt  = _re.sub(r"Locked [^.]+\.", "", char_data.get("higgsfield_prompt", "")).strip()
                clean_script = _re.sub(r"\[.*?\]", "", take.get("script", "")).strip()
                camera_angle = take.get("camera_angle", "").strip()
                voice_prompt = char_data.get("voice_prompt", "").strip()
                full_prompt  = " ".join(filter(None, [
                    camera_angle + "," if camera_angle else "",
                    base_prompt,
                    f"Voice: {voice_prompt}" if voice_prompt else "",
                    f"Dialogue: {clean_script}" if clean_script else "",
                ]))
                cmd = [
                    "generate", "create", st.session_state.get("animation_model", "seedance_2_0_mini"),
                    "--prompt", full_prompt,
                    "--aspect_ratio", "9:16",
                    "--duration", str({("char1",1):6,("char1",2):8,("char1",3):6,("char2",1):8,("char2",2):8,("char2",3):6}.get((char_id, int(take.get("take_number", 1))), int(take.get("duration_seconds", 8)))),
                    "--mode", config.HIGGSFIELD_VIDEO_MODE,
                    "--generate_audio", "true",
                    "--resolution", config.HIGGSFIELD_VIDEO_RESOLUTION,
                ]
                avatar_img = char_image_paths.get(char_id, "")
                if avatar_img and Path(avatar_img).exists():
                    cmd += ["--image", avatar_img]
                if voice_ref and voice_ref.exists():
                    cmd += ["--audio", str(voice_ref)]
                    log_step(f"{label} using voice ref")
                try:
                    cdn_url = _extract_url(run_higgsfield(cmd))
                    download_file(cdn_url, dest)
                    log_step(f"{label} OK -> {dest.name}")
                    return label, str(dest)
                except Exception as e:
                    log_step(f"{label} failed: {e}", ok=False)
                    st.warning(f"{label} failed: {e}")
                    return label, None

            # Partition into take1s and the rest
            take1s    = [(cid, t, lbl) for cid, t, lbl in all_takes if t.get("take_number", 1) == 1]
            remaining = [(cid, t, lbl) for cid, t, lbl in all_takes if t.get("take_number", 1) != 1]

            # Run take1s in parallel (one per char → typically 2)
            t1_results = _run_async_batch(
                [lambda cid=cid, t=t, lbl=lbl: _gen_drama_take(cid, t, lbl, None) for cid, t, lbl in take1s],
                max_workers=3,
            )
            for (lbl, dest_path), (char_id, _, _) in zip(t1_results, take1s):
                if dest_path:
                    take_lipsync_paths[lbl] = dest_path
                    try:
                        voice_refs[char_id] = _extract_audio_from_clip(Path(dest_path))
                        log_step(f"{char_id} voice ref extracted from take 1")
                    except Exception as ae:
                        log_step(f"{char_id} voice ref extraction failed: {ae}", ok=False)

            # Run remaining takes in parallel, each with its char's voice ref
            if remaining:
                rem_results = _run_async_batch(
                    [lambda cid=cid, t=t, lbl=lbl: _gen_drama_take(cid, t, lbl, voice_refs.get(cid))
                     for cid, t, lbl in remaining],
                    max_workers=3,
                )
                for lbl, dest_path in rem_results:
                    if dest_path:
                        take_lipsync_paths[lbl] = dest_path

            s3.update(label=f"Step 2 — Character clips done ({len(take_lipsync_paths)}/{len(all_takes)})", state="complete")
        except Exception as e:
            log_step(f"Character clip generation failed: {e}", ok=False)
            s3.update(label=f"Step 2 — FAILED: {e}", state="error")
            st.error(str(e)); _show_log(log); return

    # ── Step 3a: Title card (image + animation) ──────────────────────────────
    cards_dir = output_dir / "cards"
    cards_dir.mkdir(exist_ok=True)
    tc_data      = script.get("title_card", {})
    tc_img_dest  = cards_dir / "title_card.jpg"
    tc_mp4_dest  = cards_dir / "title_card.mp4"

    with st.status("Step 3a — Title card image...", expanded=True) as s_tc:
        try:
            from core.higgsfield_cli import generate_image as _gen_img, _extract_url as _ext_url
            from utils.downloader import download_file as _dl

            if tc_data:
                if not tc_img_dest.exists():
                    hook      = tc_data.get("hook_line", "").strip().upper()
                    base      = tc_data.get("image_prompt", "").rstrip(". ")
                    text_inst = (
                        f'The image must prominently display the bold white text "{hook}" centered on screen. '
                        "Large, clean, editorial sans-serif. Pure black background with minimal symbolic element. "
                        "Vertical 9:16 format."
                    ) if hook else ""
                    full_tc_prompt = f"{base}. {text_inst}".strip() if text_inst else base
                    resp    = _gen_img(full_tc_prompt, aspect_ratio="9:16")
                    cdn_url = _ext_url(resp)
                    _dl(cdn_url, tc_img_dest)
                    log_step(f"title_card image saved -> {tc_img_dest.name}")
                else:
                    log_step("title_card image already exists — skipping")

                s_tc.update(label="Step 3a — Title card image done", state="complete")
            else:
                log_step("No title_card in script — skipping", ok=False)
                s_tc.update(label="Step 3a — No title_card field in script", state="complete")
        except Exception as e:
            log_step(f"Title card failed: {e}", ok=False)
            s_tc.update(label=f"Step 3a — Title card FAILED: {e}", state="error")
            st.warning(f"Title card failed (non-fatal): {e}")

    # ── Step 3b: Generate text card images + animations ───────────────────────
    text_card_paths = {}
    text_cards = script.get("text_cards", [])
    # ── Step 3b: Text cards (shared helper) ──────────────────────────────────
    if st.session_state.get("include_text_cards", True):
        _run_text_card_pipeline(script, output_dir, log, step_label="Step 3b")

    # ── Save drama output pack ────────────────────────────────────────────────
    drama_output = {
        **script,
        "generated": {
            "char_image_paths": char_image_paths,
            "take_clip_paths": take_lipsync_paths,
            "text_card_paths": text_card_paths,
        },
    }
    (output_dir / "drama_output.json").write_text(
        json.dumps(drama_output, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    st.session_state["drama_output"] = drama_output
    st.session_state["generation_log"] = log
    st.session_state["screen"] = "output"
    st.success("All steps complete.")
    st.rerun()


def screen_progress():
    video_id = st.session_state["video_id"]
    all_scenes: list[Scene] = st.session_state["scenes"]
    video_type = st.session_state.get("video_type", "type1")

    if st.button("← Back to review", key="progress_back"):
        st.session_state["screen"] = "review"
        st.rerun()

    st.markdown(f"## Generating — `{video_id}`")

    if video_type == "mode2":
        _screen_progress_type2(video_id, all_scenes)
        return

    if video_type == "mode3":
        script = st.session_state.get("script_data", {})
        _screen_progress_drama(video_id, script)
        return

    st.error("Unexpected video type reached legacy pipeline. This should not happen.")
    return


def _show_log(log: list[str]):
    with st.expander("Generation log"):
        st.code("\n".join(log))


def _save_edit_timeline(scenes: list[Scene], output_dir: Path, script: dict):
    is_type2 = script.get("video_type") in ("type2", "mode2")

    timeline = {
        "video_id": script["video_id"],
        "persona": script["persona"],
        "template": script["template"],
        "angle": script["angle"],
        "video_type": script.get("video_type", "type1"),
        "total_scenes": len(scenes),
        "scenes": [],
    }

    cursor = 0
    for scene in scenes:
        duration = scene.duration_seconds

        if is_type2 and scene.type == "CUTAWAY":
            visual_label = "Silent infographic (4:3) — bottom third"
            narration_display = ""
        elif scene.type == "AVATAR":
            visual_label = "Avatar lipsync (top 2/3)" if is_type2 else "Avatar lipsync"
            narration_display = scene.narration
        else:
            visual_label = "Animated cutaway"
            narration_display = scene.narration

        entry = {
            "scene": scene.scene_number,
            "type": scene.type,
            "time_start": f"0:{cursor:02d}",
            "time_end": f"0:{cursor + duration:02d}",
            "duration_s": duration,
            "narration": narration_display,
            "visual": visual_label,
            "scene_description": scene.scene_description if is_type2 and scene.type == "CUTAWAY" else None,
            "overlay_text": scene.overlay_text,
            "overlay_timing": f"0:{cursor + 1:02d} – 0:{cursor + duration - 1:02d}" if scene.overlay_text else None,
            "overlay_position": "center lower third" if scene.overlay_text else None,
            "overlay_style": "bold white, subtle shadow, fade in/out" if scene.overlay_text else None,
            "asset": scene.final_video_path or scene.lipsync_video_path or scene.cutaway_video_path,
        }
        timeline["scenes"].append(entry)
        cursor += duration

    (output_dir / "edit_timeline.json").write_text(
        json.dumps(timeline, indent=2, ensure_ascii=False), encoding="utf-8"
    )


# ═══════════════════════════════════════════════════════════════════════════════
# SCREEN 4 — OUTPUT
# ═══════════════════════════════════════════════════════════════════════════════
def screen_output():
    scenes: list[Scene] = st.session_state.get("final_scenes") or st.session_state.get("scenes", [])
    video_id = st.session_state["video_id"]
    script = st.session_state["script_data"]
    output_dir = Path(st.session_state["output_dir"])
    video_type = st.session_state.get("video_type", "type1")

    if st.button("← Back to review", key="output_back"):
        st.session_state["screen"] = "review"
        st.rerun()

    st.markdown(f"## Output — `{video_id}`")

    col_meta1, col_meta2 = st.columns(2)
    with col_meta1:
        if video_type == "drama":
            st.markdown(f"**Story:** {script.get('story_topic', '')}")
        else:
            st.markdown(f"**Persona:** {script['persona']}")
            st.markdown(f"**Template:** {script['template']}")
    with col_meta2:
        st.markdown(f"**Angle:** {script.get('angle', '')}")

    st.markdown("---")
    st.markdown("### Final Clips")

    _is_type2_output = st.session_state.get("video_type") == "mode2"

    for scene in scenes:
        tag_class = "avatar" if scene.type == "AVATAR" else "cutaway"
        tag_label = scene.type

        # For Type 2 silent cutaways, show scene_description as the label text
        display_text = scene.narration
        if _is_type2_output and scene.type == "CUTAWAY":
            display_text = scene.scene_description or scene.image_prompt or "(silent cutaway)"

        col_info, col_video = st.columns([1, 1])
        with col_info:
            st.markdown(
                f'<div class="scene-card {tag_class}">'
                f'<span class="tag tag-{tag_class}">{tag_label}</span><br>'
                f'<strong>Scene {scene.scene_number}</strong><br>'
                f'<em>{display_text}</em>',
                unsafe_allow_html=True,
            )
            if scene.overlay_text:
                st.markdown(f"**Overlay:** {scene.overlay_text}")
            st.markdown("</div>", unsafe_allow_html=True)

        with col_video:
            clip_path = scene.final_video_path or scene.lipsync_video_path or scene.cutaway_video_path
            if clip_path and Path(clip_path).exists():
                st.video(clip_path)
            else:
                st.caption("No video generated for this scene.")

    # ── Edit timeline ──────────────────────────────────────────────────────────
    st.markdown("---")
    st.markdown("### Edit Timeline JSON")
    timeline_path = output_dir / "edit_timeline.json"
    if timeline_path.exists():
        timeline_data = timeline_path.read_text(encoding="utf-8")
        with st.expander("View timeline JSON", expanded=False):
            st.json(json.loads(timeline_data))

        st.download_button(
            "Download edit_timeline.json",
            data=timeline_data,
            file_name=f"{video_id}_edit_timeline.json",
            mime="application/json",
        )

    # ── Edit notes ────────────────────────────────────────────────────────────
    st.markdown("---")
    if _is_type2_output:
        st.markdown("### Editor Notes — Type 2 Split-screen")
        st.caption("Stack avatar clips (top 2/3, 9:16) with infographic clips (bottom 1/3, 4:3) simultaneously. Cutaways are silent. Avatar audio drives the timeline.")
        avatar_scenes_out = [s for s in scenes if s.type == "AVATAR"]
        cutaway_scenes_out = [s for s in scenes if s.type == "CUTAWAY"]
        st.markdown(f"**Avatar clips:** {len(avatar_scenes_out)} × 30s")
        st.markdown(f"**Infographic clips:** {len(cutaway_scenes_out)} × 5s — distribute {len(cutaway_scenes_out)//2} per avatar clip")
    else:
        st.markdown("### Manual Overlays for Editor")
        for scene in scenes:
            if scene.overlay_text:
                st.markdown(
                    f"**Scene {scene.scene_number}:** `{scene.overlay_text}` — "
                    f"center lower third, bold white, fade in/out"
                )

    # ── ZIP download ───────────────────────────────────────────────────────────
    st.markdown("---")
    zip_buf = _build_zip(scenes, output_dir, video_id)
    st.download_button(
        "Download all clips + timeline (ZIP)",
        data=zip_buf,
        file_name=f"{video_id}_output.zip",
        mime="application/zip",
    )

    if st.button("New video"):
        for key in ["script_data", "scenes", "video_id", "output_dir", "generation_log", "final_scenes", "avatar_image_path", "voice_ref_upload_path"]:
            st.session_state[key] = None
        st.session_state["generation_log"] = []
        st.session_state["news_content_edit"] = ""
        st.session_state["fetch_status"] = None
        st.session_state["fetch_error_msg"] = ""
        st.session_state["lipsync_characters"] = []
        st.session_state["lipsync_script_raw"] = ""
        st.session_state["screen"] = "input"
        st.rerun()


def _build_zip(scenes: list[Scene], output_dir: Path, video_id: str) -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for scene in scenes:
            for attr in ("final_video_path", "lipsync_video_path", "cutaway_video_path", "audio_path"):
                p = getattr(scene, attr, None)
                if p and Path(p).exists():
                    zf.write(p, arcname=Path(p).name)
                    break  # only include the best available clip per scene

        timeline_path = output_dir / "edit_timeline.json"
        if timeline_path.exists():
            zf.write(str(timeline_path), arcname="edit_timeline.json")

    buf.seek(0)
    return buf.read()


# ═══════════════════════════════════════════════════════════════════════════════
# SCREEN 5 — RE-ANIMATE FROM SAVED IMAGES
# ═══════════════════════════════════════════════════════════════════════════════
def screen_reanimate():
    """
    Skips audio + image generation. Restores paths from disk and re-runs
    animation (Step 3) + audio merge (Step 4) only.
    Use when images are generated but animation crashed.
    """
    video_id = st.session_state["video_id"]
    all_scenes: list[Scene] = st.session_state["scenes"]
    output_dir = Path(st.session_state["output_dir"])
    _anim_model = st.session_state.get("animation_model", "seedance_2_0_mini")
    _anim_label = {"seedance_2_0_mini": "Seedance 2.0 Mini", "seedance_2_0": "Seedance 2.0 Fast"}.get(_anim_model, _anim_model)

    if st.button("← Back to output", key="reanimate_back"):
        st.session_state["screen"] = "output"
        st.rerun()

    st.markdown(f"## Re-animating — `{video_id}`")
    st.caption(f"Restoring saved images and re-running animation via {_anim_label}. Skipping audio + image generation.")

    cutaway_scenes = [s for s in all_scenes if s.type == "CUTAWAY"]
    avatar_scenes  = [s for s in all_scenes if s.type == "AVATAR"]

    images_dir = output_dir / "images"
    audio_dir  = output_dir / "audio"

    # ── Restore image + audio paths from disk ─────────────────────────────────
    missing_images = []
    for scene in cutaway_scenes:
        img = images_dir / f"scene{scene.scene_number}_cutaway.jpg"
        if img.exists():
            scene.image_path = str(img)
        else:
            missing_images.append(scene.scene_number)

        for ext in ("mp3", "wav"):
            aud = audio_dir / f"seg{scene.scene_number}.{ext}"
            if aud.exists():
                scene.audio_path = str(aud)
                break

    if missing_images:
        st.warning(f"Missing images for scenes: {missing_images}. Those scenes will be skipped.")
    else:
        st.success(f"Found all {len(cutaway_scenes)} images. Starting animation...")

    log = []
    def log_step(msg: str, ok: bool = True):
        log.append(f"[{'OK' if ok else 'FAIL'}] {msg}")

    # ── Step 3: Animate ───────────────────────────────────────────────────────
    with st.status(f"Animating cutaway scenes ({_anim_label})...", expanded=True) as s3:
        cutaway_progress = st.progress(0)
        try:
            def cutaway_cb(done, total):
                cutaway_progress.progress(done / total, text=f"Cutaway {done}/{total}")

            cutaway_scenes = animate_cutaway_scenes(
                cutaway_scenes, output_dir,
                beat=st.session_state.get("script_data", {}).get("beat", "Finance"),
                video_model=_anim_model,
                progress_callback=cutaway_cb,
            )
            log_step(f"Animation complete — {_anim_label}")
            s3.update(label=f"Animations done ({_anim_label})", state="complete")
        except Exception as e:
            log_step(f"Animation failed: {e}", ok=False)
            s3.update(label=f"Animation FAILED: {e}", state="error")
            st.error(f"Animation failed: {e}")
            _show_log(log)
            return

    # ── Step 4: Merge audio ───────────────────────────────────────────────────
    with st.status("Merging audio onto cutaway clips...", expanded=False) as s4:
        try:
            cutaway_scenes = merge_cutaway_audio(cutaway_scenes, output_dir)
            log_step("Audio merge complete")
            s4.update(label="Audio merged", state="complete")
        except Exception as e:
            log_step(f"Audio merge failed: {e}", ok=False)
            s4.update(label=f"Merge FAILED: {e}", state="error")
            st.error(f"Audio merge failed: {e}")
            _show_log(log)
            return

    final_scenes = sorted(avatar_scenes + cutaway_scenes, key=lambda s: s.scene_number)
    _save_edit_timeline(final_scenes, output_dir, st.session_state["script_data"])

    st.session_state["final_scenes"] = final_scenes
    st.session_state["generation_log"] = log
    st.session_state["screen"] = "output"
    st.success("Re-animation complete. Loading output...")
    st.rerun()


# ═══════════════════════════════════════════════════════════════════════════════
# SCREEN 2b — DRAMA SCRIPT REVIEW
# ═══════════════════════════════════════════════════════════════════════════════
def screen_review_drama():
    script = st.session_state["script_data"]

    if st.button("← Home", key="drama_review_home"):
        st.session_state["screen"] = "input"
        st.rerun()

    st.markdown(f"## Micro-Drama Script Review — `{script['video_id']}`")

    col1, col2 = st.columns(2)
    with col1:
        st.markdown(f"**Story:** {script.get('story_topic', '')}")
        st.markdown(f"**Angle:** {script.get('angle', '')}")
    with col2:
        st.markdown(f"**Beat:** {script.get('beat', '')}")
        st.markdown(f"**Template:** {script.get('template', '')}")
        st.caption("9:16 vertical — 60s — two-character dialogue")

    st.markdown("---")

    # ── CHARACTERS ────────────────────────────────────────────────────────────
    st.markdown("### Characters")
    chars = script.get("characters", {})
    col_c1, col_c2 = st.columns(2)

    for col, char_id, label in [(col_c1, "char1", "Character 1 — Human Cost"), (col_c2, "char2", "Character 2 — Systemic Layer")]:
        with col:
            char = chars.get(char_id, {})
            st.markdown(
                f'<div class="scene-card avatar">'
                f'<span class="tag tag-avatar">{label}</span><br>'
                f'<strong>Role:</strong> {char.get("role", "")}<br>'
                f'<strong>Appearance:</strong> {char.get("appearance", "")}<br>'
                f'<strong>Setting:</strong> {char.get("setting", "")}<br>'
                f'<strong>Lighting:</strong> {char.get("lighting", "")}<br>'
                f'<strong>Register:</strong> {char.get("emotional_register", "")}'
                f'</div>',
                unsafe_allow_html=True,
            )
            with st.expander(f"{char_id} — Avatar image prompt"):
                new_img = st.text_area(
                    "Avatar image prompt",
                    value=char.get("avatar_image_prompt", ""),
                    key=f"{char_id}_img",
                    height=120,
                    label_visibility="collapsed",
                )
                script["characters"][char_id]["avatar_image_prompt"] = new_img
                # Show existing image if already generated
                existing = Path(st.session_state.get("output_dir", "output")) / "images" / f"{char_id}_avatar.jpg"
                if existing.exists():
                    st.image(str(existing), width=180, caption=f"{char_id} — current")
                if st.button("Generate image", key=f"gen_img_{char_id}"):
                    _generate_single_char_image(script, char_id)

            with st.expander(f"{char_id} — Voice prompt"):
                new_voice = st.text_area(
                    "Voice prompt",
                    value=char.get("voice_prompt", ""),
                    key=f"{char_id}_voice",
                    height=80,
                    label_visibility="collapsed",
                )
                script["characters"][char_id]["voice_prompt"] = new_voice

            with st.expander(f"{char_id} — Higgsfield lipsync prompt"):
                new_hf = st.text_area(
                    "Higgsfield prompt",
                    value=char.get("higgsfield_prompt", ""),
                    key=f"{char_id}_hf",
                    height=120,
                    label_visibility="collapsed",
                )
                script["characters"][char_id]["higgsfield_prompt"] = new_hf

    st.markdown("---")

    # ── TAKES ─────────────────────────────────────────────────────────────────
    st.markdown("### Dialogue Takes")
    takes = script.get("takes", {})

    st.markdown("#### Character 1 — 3 Takes")
    for i, take in enumerate(takes.get("char1", [])):
        t_num = int(take.get("take_number", i + 1))
        t_start = take.get("timecode_start", "")
        t_end = take.get("timecode_end", "")
        t_dur = take.get("duration_seconds", "")
        t_purpose = take.get("purpose", "")
        with st.expander(f"Take {t_num}  |  {t_start}–{t_end}  ({t_dur}s)  —  {t_purpose}", expanded=True):
            new_script = st.text_area(
                "Script",
                value=take.get("script", ""),
                key=f"char1_take{t_num}",
                height=100,
            )
            script["takes"]["char1"][i]["script"] = new_script
            if st.button(f"Generate this clip", key=f"gen_char1_take{t_num}"):
                _clips_dir = Path(st.session_state.get("output_dir", "output")) / "clips"
                _take1_mp4 = _clips_dir / "char1_take1.mp4"
                _vref = None
                if t_num > 1:
                    if _take1_mp4.exists():
                        try:
                            _vref = _extract_audio_from_clip(_take1_mp4)
                        except Exception:
                            st.warning("Could not extract voice ref from Take 1 — generating without voice consistency.")
                    else:
                        st.warning("Take 1 not generated yet — voice consistency won't be maintained. Generate Take 1 first for best results.")
                _generate_single_drama_clip(script, "char1", take, t_num, voice_ref=_vref)

    st.markdown("#### Character 2 — 3 Takes")
    for i, take in enumerate(takes.get("char2", [])):
        t_num = int(take.get("take_number", i + 1))
        t_start = take.get("timecode_start", "")
        t_end = take.get("timecode_end", "")
        t_dur = take.get("duration_seconds", "")
        t_purpose = take.get("purpose", "")
        with st.expander(f"Take {t_num}  |  {t_start}–{t_end}  ({t_dur}s)  —  {t_purpose}", expanded=True):
            new_script = st.text_area(
                "Script",
                value=take.get("script", ""),
                key=f"char2_take{t_num}",
                height=100,
            )
            script["takes"]["char2"][i]["script"] = new_script
            if st.button(f"Generate this clip", key=f"gen_char2_take{t_num}"):
                _clips_dir = Path(st.session_state.get("output_dir", "output")) / "clips"
                _take1_mp4 = _clips_dir / "char2_take1.mp4"
                _vref = None
                if t_num > 1:
                    if _take1_mp4.exists():
                        try:
                            _vref = _extract_audio_from_clip(_take1_mp4)
                        except Exception:
                            st.warning("Could not extract voice ref from Take 1 — generating without voice consistency.")
                    else:
                        st.warning("Take 1 not generated yet — voice consistency won't be maintained. Generate Take 1 first for best results.")
                _generate_single_drama_clip(script, "char2", take, t_num, voice_ref=_vref)

    st.markdown("---")

    # ── SPLIT SCREEN ──────────────────────────────────────────────────────────
    st.markdown("### Split Screen Brief (0:42–0:52)")
    split = script.get("split_screen", {})
    col_s1, col_s2 = st.columns(2)
    with col_s1:
        st.markdown(f"**Layout:** {split.get('layout', '')}")
        st.markdown(f"**Stagger:** {split.get('stagger_seconds', '')}s")
        st.markdown(f"**Audio:** {split.get('audio_mix', '')}")
        st.markdown(f"**Exit:** {split.get('exit', '')}")
    with col_s2:
        new_conv = st.text_input(
            "Convergence line (both characters say this simultaneously)",
            value=split.get("convergence_line", ""),
            key="convergence_line",
        )
        script["split_screen"]["convergence_line"] = new_conv

    st.markdown("---")

    # ── TITLE CARD ────────────────────────────────────────────────────────────
    st.markdown("### Title Card")
    tc = script.get("title_card", {})
    if tc:
        with st.expander(f"Title Card | 0:00–0:04 (4s) — hook line", expanded=False):
            new_hook = st.text_input("Hook line", value=tc.get("hook_line", ""), key="title_card_hook")
            script["title_card"]["hook_line"] = new_hook

            new_tc_prompt = st.text_area(
                "Image prompt (nano_banana_2)",
                value=tc.get("image_prompt", ""),
                key="title_card_imgprompt",
                height=80,
            )
            script["title_card"]["image_prompt"] = new_tc_prompt

            existing_img = Path(st.session_state.get("output_dir", "output")) / "cards" / "title_card.jpg"

            if existing_img.exists():
                st.image(str(existing_img), width=150, caption="Title card image")

            if st.button("Generate image", key="gen_title_img"):
                _generate_title_card_image(script)
    else:
        st.warning("No title_card in script. Regenerate script to get this field.")

    st.markdown("---")

    # ── TEXT CARDS ────────────────────────────────────────────────────────────
    st.markdown("### Text Cards")
    text_cards = script.get("text_cards", [])
    for ci, card in enumerate(text_cards):
        card_id = int(card.get("card_id", ci + 1))
        t_start = card.get("timecode_start", "")
        t_end = card.get("timecode_end", "")
        dur = card.get("duration_seconds", "")
        purpose = card.get("purpose", "")
        label = f"Card {card_id}  |  {t_start}–{t_end}  ({dur}s)  —  {purpose}"
        with st.expander(label, expanded=True):
            # Text lines
            lines = card.get("text_lines", card.get("lines", []))
            new_lines = []
            for i, line in enumerate(lines):
                new_line = st.text_input(f"Line {i + 1}", value=line, key=f"card{card_id}_line{i}")
                new_lines.append(new_line)
            script["text_cards"][ci]["text_lines"] = new_lines

            # Overlay text
            new_overlay = st.text_input(
                "Overlay text (header)",
                value=card.get("overlay_text", ""),
                key=f"card{card_id}_overlay",
            )
            script["text_cards"][ci]["overlay_text"] = new_overlay

            # Image prompt
            new_img_prompt = st.text_area(
                "Image prompt (nano_banana_2)",
                value=card.get("image_prompt", ""),
                key=f"card{card_id}_imgprompt",
                height=100,
            )
            script["text_cards"][ci]["image_prompt"] = new_img_prompt

            # Show existing image or generate button
            existing_img = Path(st.session_state.get("output_dir", "output")) / "cards" / f"textcard_{card_id}.jpg"
            if existing_img.exists():
                st.image(str(existing_img), width=200, caption=f"Card {card_id} — current")
            btn_col1, btn_col2 = st.columns(2)
            with btn_col1:
                if st.button("Generate image", key=f"gen_card_img_{card_id}"):
                    _generate_card_image_only(script, ci, card_id)
            with btn_col2:
                if st.button("Animate (Seedance 4s)", key=f"animate_card_{card_id}"):
                    _animate_card_only(script, ci, card_id)

    st.markdown("---")

    # ── STORYBOARD ────────────────────────────────────────────────────────────
    st.markdown("### Storyboard")
    storyboard = script.get("storyboard", [])
    if storyboard:
        import pandas as pd
        sb_df = pd.DataFrame(storyboard)
        st.dataframe(sb_df, use_container_width=True, hide_index=True)

    st.markdown("---")

    # ── TOOL EXECUTION ORDER ──────────────────────────────────────────────────
    st.markdown("### Production Order")
    exec_order = script.get("tool_execution_order", [])
    for step in exec_order:
        st.markdown(f"- {step}")

    st.markdown("---")

    # ── NEGATIVE PROMPT ───────────────────────────────────────────────────────
    with st.expander("Negative prompt (apply to all lipsync generations)"):
        st.code(script.get("negative_prompt", ""), language=None)

    st.markdown("---")

    # ── Pre-flight checklist (drama) ───────────────────────────────────────────
    if st.session_state.get("mode", "[FULL]") != "[PACK]":
        st.markdown("### Pre-flight checklist")
        drama_issues = _preflight_checks_drama(script)
        blockers = [i for i in drama_issues if not i.startswith("WARN:")]
        warnings = [i[5:] for i in drama_issues if i.startswith("WARN:")]
        for issue in blockers:
            st.error(f"BLOCKED — {issue}")
        for issue in warnings:
            st.warning(f"WARNING — {issue}")
        if blockers:
            st.error("Fix the BLOCKED issues above before generating.")
        elif warnings:
            st.info("Warnings present — you can still generate, but review them. Edit takes in the review screen above.")
        else:
            st.success("All checks passed — ready to generate.")

    col_back, col_fwd = st.columns([1, 3])
    with col_back:
        if st.button("Back to input"):
            st.session_state["screen"] = "input"
            st.rerun()
    with col_fwd:
        mode = st.session_state.get("mode", "[FULL]")
        if mode == "[PACK]":
            drama_json = json.dumps(script, indent=2, ensure_ascii=False)
            st.download_button(
                "Download drama production pack JSON",
                data=drama_json,
                file_name=f"{script['video_id']}_drama_pack.json",
                mime="application/json",
                type="primary",
            )
        else:
            drama_ok = not any(not i.startswith("WARN:") for i in _preflight_checks_drama(script))
            if st.button("Generate video", type="primary", disabled=not drama_ok):
                st.session_state["screen"] = "progress"
                st.rerun()

    # Save any edits back to script_data
    st.session_state["script_data"] = script


# ═══════════════════════════════════════════════════════════════════════════════
# TYPE 1 LIPSYNC — Input, Review, Per-scene helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _render_lipsync_input():
    st.markdown("### Script")
    raw_script = st.text_area(
        "Paste your script",
        height=300,
        placeholder="Scene 1: Mayank stands near the door...\nDialogue: Bhai, darwaza band kar...",
        key="lipsync_script_raw",
    )

    st.markdown("### Characters")
    st.caption("Add each character by name and upload their reference image.")

    chars = st.session_state.get("lipsync_characters", [])

    col_name, col_img, col_add = st.columns([2, 2, 1])
    with col_name:
        new_char_name = st.text_input(
            "Character name",
            key="new_char_name",
            label_visibility="collapsed",
            placeholder="e.g. Mayank",
        )
    with col_img:
        new_char_img = st.file_uploader(
            "Image",
            type=["jpg", "jpeg", "png"],
            key="new_char_img",
            label_visibility="collapsed",
        )
    with col_add:
        if st.button("Add character", use_container_width=True):
            if new_char_name.strip():
                img_path = ""
                if new_char_img:
                    img_path = _save_uploaded_image(new_char_img, config.OUTPUT_DIR / "_avatars")
                chars.append({"name": new_char_name.strip(), "image_path": img_path})
                st.session_state["lipsync_characters"] = chars
                st.rerun()

    for i, char in enumerate(chars):
        col_c, col_del = st.columns([4, 1])
        with col_c:
            img_label = Path(char["image_path"]).name if char["image_path"] else "no image"
            st.caption(f"**{char['name']}** — {img_label}")
            if char["image_path"] and Path(char["image_path"]).exists():
                st.image(char["image_path"], width=80)
        with col_del:
            if st.button("Remove", key=f"rm_char_{i}"):
                chars.pop(i)
                st.session_state["lipsync_characters"] = chars
                st.rerun()

    st.markdown("### Voice Ref (optional)")
    st.caption("Upload an MP3/WAV to lock voice consistency across all scenes. If not set, extracted from Scene 1 after generation.")
    _ls_vr_file = st.file_uploader(
        "Voice reference (MP3/WAV)",
        type=["mp3", "wav"],
        key="ls_input_voice_ref",
        label_visibility="collapsed",
    )
    if _ls_vr_file:
        _ls_vr_tmp = config.OUTPUT_DIR / "_avatars"
        _ls_vr_tmp.mkdir(exist_ok=True)
        _ls_vr_save = str(_ls_vr_tmp / _ls_vr_file.name)
        with open(_ls_vr_save, "wb") as f:
            f.write(_ls_vr_file.read())
        st.session_state["voice_ref_upload_path"] = _ls_vr_save
    _ls_vr_cur = st.session_state.get("voice_ref_upload_path") or ""
    if _ls_vr_cur and Path(_ls_vr_cur).exists():
        st.caption(f"Active: {Path(_ls_vr_cur).name}")

    st.markdown("---")
    use_as_is = st.checkbox(
        "Use script as-is (format only, do not rewrite dialogue)",
        value=st.session_state.get("lipsync_use_as_is", False),
        key="lipsync_use_as_is_toggle",
    )
    st.session_state["lipsync_use_as_is"] = use_as_is

    _active_provider = st.session_state.get("llm_provider", "groq")
    can_format = bool(raw_script.strip()) if raw_script else False
    if not can_format:
        st.warning("Paste your script above to continue.")

    if st.button("Format Script into Scenes", type="primary", disabled=not can_format):
        char_names = [c["name"] for c in chars] if chars else ["Character 1"]
        with st.spinner("Formatting script into scenes..."):
            try:
                from core.script_generator import format_lipsync_script
                script_data = format_lipsync_script(
                    raw_script=raw_script.strip(),
                    characters=char_names,
                    provider=_active_provider,
                    use_as_is=use_as_is,
                    scene_sequence=st.session_state.get("scene_sequence", []),
                    video_duration=st.session_state.get("video_duration", 40),
                )
                # Embed character image paths so JSON load restores them
                if chars:
                    script_data["lipsync_characters"] = chars
                video_dir = config.OUTPUT_DIR / script_data["video_id"]
                video_dir.mkdir(parents=True, exist_ok=True)
                (video_dir / "script.json").write_text(
                    json.dumps(script_data, indent=2, ensure_ascii=False), encoding="utf-8"
                )
                st.session_state["script_data"] = script_data
                st.session_state["video_id"] = script_data["video_id"]
                st.session_state["output_dir"] = str(video_dir)
                st.session_state["screen"] = "lipsync_review"
                st.rerun()
            except Exception as e:
                st.error(f"Script formatting failed: {e}")


def _enhance_lipsync_scene(scene: dict, enhance_prompt: str, provider: str) -> dict:
    """Calls LLM to enhance scene_description + dialogue based on optional user instruction."""
    from core.script_generator import _call_groq, _call_claude
    import re as _re

    system = (
        "You are a video scene director. Enhance the given scene for a 10-second lipsync clip. "
        "Return ONLY valid JSON with exactly two keys: scene_description, dialogue. "
        "dialogue max 25 spoken words. No markdown. No commentary. No preamble."
    )
    user_msg = (
        f"Current scene_description: {scene.get('scene_description', '')}\n"
        f"Current dialogue: {scene.get('dialogue', '')}\n"
        f"Character: {scene.get('character', '')}\n"
        f"Enhancement instruction: {enhance_prompt or 'Make it more cinematic and emotionally impactful.'}"
    )

    if provider == "claude":
        raw = _call_claude(system, user_msg)
    else:
        raw = _call_groq(system, user_msg)

    raw = _re.sub(r"^```(?:json)?\s*", "", raw.strip())
    raw = _re.sub(r"\s*```$", "", raw)
    first = raw.find("{")
    if first > 0:
        raw = raw[first:]

    result = json.loads(raw)
    if result.get("scene_description"):
        scene["scene_description"] = result["scene_description"]
    if result.get("dialogue"):
        scene["dialogue"] = result["dialogue"]
    return scene


def _generate_lipsync_clip(scene: dict, char_image_path: str, output_dir: Path, placeholder=None, voice_ref: Path = None):
    """Generates a Higgsfield seedance_2_0 clip for one lipsync scene."""
    from core.higgsfield_cli import _extract_url
    from utils.cli_runner import run_higgsfield
    from utils.downloader import download_file

    ui = placeholder or st  # ponytail: use placeholder for async, st for sync

    clips_dir = output_dir / "clips"
    clips_dir.mkdir(exist_ok=True)
    n = scene["scene_number"]
    dest = clips_dir / f"scene{n}_lipsync.mp4"

    if dest.exists():
        ui.success(f"Scene {n} already generated.")
        ui.video(dest.read_bytes())
        return dest

    override = st.session_state.get(f"scene_prompt_override_{n}", "").strip()
    dialogue = re.sub(r"\[.*?\]", "", scene.get("dialogue", "")).strip()

    if override:
        full_prompt = override
    else:
        full_prompt = _build_avatar_prompt(dialogue, scene.get("background", ""), scene.get("scene_description", ""))

    cmd = [
        "generate", "create", st.session_state.get("animation_model", "seedance_2_0_mini"),
        "--prompt", full_prompt,
        "--aspect_ratio", "9:16",
        "--duration", "8",
        "--mode", config.HIGGSFIELD_VIDEO_MODE,
        "--generate_audio", "true",
        "--resolution", config.HIGGSFIELD_VIDEO_RESOLUTION,
    ]
    if char_image_path and Path(char_image_path).exists():
        cmd += ["--image", char_image_path]
    if voice_ref and voice_ref.exists():
        cmd += ["--audio", str(voice_ref)]

    with ui.spinner(f"Generating scene {n} (Seedance 8s)..."):
        try:
            response = run_higgsfield(cmd)
            cdn_url = _extract_url(response)
            download_file(cdn_url, dest)
            ui.success(f"Scene {n} done")
            ui.video(dest.read_bytes())
            return dest
        except Exception as e:
            ui.error(f"Scene {n} failed: {e}")
            return None


def screen_lipsync_review():
    script = st.session_state["script_data"]
    chars = st.session_state.get("lipsync_characters", [])
    output_dir = Path(st.session_state["output_dir"])
    provider = st.session_state.get("llm_provider", "groq")

    char_map = {c["name"]: c["image_path"] for c in chars}
    char_names = [c["name"] for c in chars] if chars else ["Character 1"]

    if st.button("← Back to input", key="lipsync_review_back"):
        st.session_state["screen"] = "input"
        st.rerun()

    total = script.get("total_scenes", len(script.get("scenes", [])))
    st.markdown(f"## Type 1 Lipsync — `{script['video_id']}`")
    st.caption(f"{total} scenes · 8s each · {total * 8}s total")

    scenes = script.get("scenes", [])

    for i, scene in enumerate(scenes):
        n = scene["scene_number"]
        stype = scene.get("scene_type", "LIPSYNC")
        char = scene.get("character", char_names[0] if char_names else "")
        _dur_label = "4s" if stype == "TEXT_CARD" else "8s"
        with st.expander(f"Scene {n} — {stype}  |  {_dur_label}", expanded=True):

            new_desc = st.text_area(
                "Scene description",
                value=scene.get("scene_description", ""),
                key=f"ls_desc_{n}",
                height=100,
            )
            script["scenes"][i]["scene_description"] = new_desc

            if stype == "TEXT_CARD":
                new_overlay = st.text_input(
                    "Card text",
                    value=scene.get("overlay_text", scene.get("dialogue", "")),
                    key=f"ls_overlay_{n}",
                )
                new_card_img_prompt = st.text_area(
                    "Background image prompt",
                    value=scene.get("image_prompt", ""),
                    key=f"ls_card_imgprompt_{n}",
                    height=80,
                )
                script["scenes"][i]["overlay_text"] = new_overlay
                script["scenes"][i]["image_prompt"] = new_card_img_prompt

                card_img_dest  = output_dir / "cards" / f"scene{n}_textcard.jpg"
                card_clip_dest = output_dir / "clips" / f"scene{n}_textcard.mp4"
                if card_img_dest.exists():
                    st.image(str(card_img_dest), caption=f"Scene {n} card")
                if card_clip_dest.exists():
                    st.video(card_clip_dest.read_bytes())

                col_cimg, col_canim = st.columns(2)
                with col_cimg:
                    if st.button("Generate image", key=f"ls_gen_{n}", type="primary"):
                        from core.higgsfield_cli import generate_image, _extract_url
                        from utils.downloader import download_file
                        (output_dir / "cards").mkdir(exist_ok=True)
                        _card_dict = {"overlay_text": new_overlay, "image_prompt": new_card_img_prompt}
                        with st.spinner(f"Generating card image for scene {n}..."):
                            try:
                                cdn_url = _extract_url(generate_image(_build_card_image_prompt(_card_dict), aspect_ratio="9:16"))
                                download_file(cdn_url, card_img_dest)
                                script["scenes"][i]["image_path"] = str(card_img_dest)
                                st.session_state["script_data"] = script
                                st.image(str(card_img_dest), caption=f"Scene {n} card")
                                st.success("Card image saved.")
                            except Exception as e:
                                st.error(f"Card image failed: {e}")

                with col_canim:
                    if st.button("Animate", key=f"ls_canim_{n}", type="primary", disabled=not card_img_dest.exists()):
                        from core.higgsfield_cli import _extract_url
                        from utils.cli_runner import run_higgsfield
                        from utils.downloader import download_file
                        (output_dir / "clips").mkdir(exist_ok=True)
                        _text_ref = f'Text: "{new_overlay}".' if new_overlay else ""
                        with st.spinner(f"Animating card scene {n}..."):
                            try:
                                cmd = [
                                    "generate", "create", st.session_state.get("animation_model", "seedance_2_0_mini"),
                                    "--prompt", f"{_CARD_ANIM_PROMPT} {_text_ref}".strip(),
                                    "--image", str(card_img_dest),
                                    "--aspect_ratio", "9:16",
                                    "--duration", "4",
                                    "--mode", "fast",
                                    "--generate_audio", "true",
                                    "--resolution", "480p",
                                ]
                                cdn_url = _extract_url(run_higgsfield(cmd))
                                download_file(cdn_url, card_clip_dest)
                                script["scenes"][i]["clip_path"] = str(card_clip_dest)
                                st.session_state["script_data"] = script
                                st.video(card_clip_dest.read_bytes())
                                st.success(f"Scene {n} card animated.")
                            except Exception as e:
                                st.error(f"Card animation failed: {e}")

            elif stype == "INFOGRAPHIC":
                new_dialogue = st.text_area(
                    "Narration",
                    value=scene.get("dialogue", "") or scene.get("narration", ""),
                    key=f"ls_dial_{n}",
                    height=80,
                )
                spoken = re.sub(r"\[.*?\]", "", new_dialogue).strip()
                wc = len(spoken.split()) if spoken else 0
                if wc > 13:
                    st.warning(f"{wc} spoken words — max 13 for 8s. Trim before generating.")
                else:
                    st.caption(f"{wc}/13 words")

                new_img_prompt = st.text_area(
                    "Image prompt",
                    value=scene.get("image_prompt", ""),
                    key=f"ls_imgprompt_{n}",
                    height=100,
                )
                script["scenes"][i]["dialogue"] = new_dialogue
                script["scenes"][i]["narration"] = new_dialogue
                script["scenes"][i]["image_prompt"] = new_img_prompt

                _info_anim_prompt = f"{new_img_prompt}. Narration: {new_dialogue}" if new_dialogue else new_img_prompt
                # Force refresh if narration not yet reflected in stored prompt
                _stored_prompt = st.session_state.get(f"scene_prompt_override_{n}", "")
                if new_dialogue and new_dialogue not in _stored_prompt:
                    st.session_state[f"scene_prompt_override_{n}"] = _info_anim_prompt
                with st.expander("Seedance prompt (editable)", expanded=False):
                    _info_anim_prompt = st.text_area(
                        "Full prompt sent to Seedance",
                        value=st.session_state.get(f"scene_prompt_override_{n}", _info_anim_prompt),
                        key=f"prompt_editor_{n}",
                        height=160,
                        label_visibility="collapsed",
                    )
                    st.session_state[f"scene_prompt_override_{n}"] = _info_anim_prompt

                img_dest = output_dir / "images" / f"scene{n}_infographic.jpg"
                clip_dest = output_dir / "clips" / f"scene{n}_infographic.mp4"

                if img_dest.exists():
                    st.image(str(img_dest), caption=f"Scene {n} image")
                if clip_dest.exists():
                    st.video(clip_dest.read_bytes())

                col_img, col_anim = st.columns(2)
                with col_img:
                    if st.button("Generate image", key=f"ls_gen_{n}", type="primary"):
                        from core.higgsfield_cli import generate_image, _extract_url
                        from utils.downloader import download_file
                        (output_dir / "images").mkdir(exist_ok=True)
                        with st.spinner(f"Generating image for scene {n}..."):
                            try:
                                cdn_url = _extract_url(generate_image(new_img_prompt or new_desc, aspect_ratio="9:16"))
                                download_file(cdn_url, img_dest)
                                script["scenes"][i]["image_path"] = str(img_dest)
                                st.session_state["script_data"] = script
                                st.image(str(img_dest), caption=f"Scene {n} image")
                                st.success("Image saved.")
                            except Exception as e:
                                st.error(f"Image generation failed: {e}")

                with col_anim:
                    _can_animate = img_dest.exists()
                    if st.button("Animate", key=f"ls_anim_{n}", type="primary", disabled=not _can_animate):
                        from core.higgsfield_cli import _extract_url
                        from utils.cli_runner import run_higgsfield
                        from utils.downloader import download_file
                        (output_dir / "clips").mkdir(exist_ok=True)
                        _s1_clip = next(
                            (output_dir / "clips" / f for f in ("scene1_lipsync.mp4", "scene1_infographic.mp4") if (output_dir / "clips" / f).exists()),
                            None,
                        )
                        _vref = None
                        if _s1_clip:
                            try: _vref = _extract_audio_from_clip(_s1_clip)
                            except Exception: pass
                        elif n > 1:
                            st.warning("Scene 1 not generated yet — animating without voice ref. Generate scene 1 first for voice continuity.")
                        with st.spinner(f"Animating scene {n}..."):
                            try:
                                _anim_prompt = st.session_state.get(f"scene_prompt_override_{n}") or (f"{new_img_prompt}. Narration: {new_dialogue}" if new_dialogue else new_img_prompt)
                                cmd = [
                                    "generate", "create", st.session_state.get("animation_model", "seedance_2_0_mini"),
                                    "--prompt", _anim_prompt,
                                    "--image", str(img_dest),
                                    "--aspect_ratio", "9:16",
                                    "--duration", "8",
                                    "--mode", config.HIGGSFIELD_VIDEO_MODE,
                                    "--generate_audio", "true",
                                    "--resolution", config.HIGGSFIELD_VIDEO_RESOLUTION,
                                ]
                                if _vref and _vref.exists():
                                    cmd += ["--audio", str(_vref)]
                                cdn_url = _extract_url(run_higgsfield(cmd))
                                download_file(cdn_url, clip_dest)
                                script["scenes"][i]["clip_path"] = str(clip_dest)
                                st.session_state["script_data"] = script
                                st.video(clip_dest.read_bytes())
                                st.success(f"Scene {n} animated.")
                            except Exception as e:
                                st.error(f"Animation failed: {e}")

            else:
                # LIPSYNC (or fallback)
                new_dialogue = st.text_area(
                    "Dialogue",
                    value=scene.get("dialogue", ""),
                    key=f"ls_dial_{n}",
                    height=80,
                )
                spoken = re.sub(r"\[.*?\]", "", new_dialogue).strip()
                wc = len(spoken.split()) if spoken else 0
                if wc > 13:
                    st.warning(f"{wc} spoken words — max 13 for 8s. Trim before generating.")
                else:
                    st.caption(f"{wc}/13 words")

                new_char = st.selectbox(
                    "Character",
                    char_names,
                    index=char_names.index(char) if char in char_names else 0,
                    key=f"ls_char_{n}",
                )

                script["scenes"][i]["dialogue"] = new_dialogue
                script["scenes"][i]["character"] = new_char

                _ls_prompt = _build_avatar_prompt(
                    re.sub(r"\[.*?\]", "", new_dialogue or "").strip(),
                    scene_description=new_desc or "",
                )
                with st.expander("Seedance prompt (editable)", expanded=False):
                    _lsp = st.text_area(
                        "Full prompt sent to Seedance",
                        value=st.session_state.get(f"scene_prompt_override_{n}", _ls_prompt),
                        key=f"prompt_editor_{n}",
                        height=160,
                        label_visibility="collapsed",
                    )
                    st.session_state[f"scene_prompt_override_{n}"] = _lsp

                col_enh, col_gen = st.columns([2, 1])
                with col_enh:
                    with st.expander("Enhance this scene"):
                        enhance_prompt = st.text_input(
                            "Enhancement instruction (optional)",
                            placeholder="Make it more tense, add rain, closer shot...",
                            key=f"ls_enh_prompt_{n}",
                            label_visibility="collapsed",
                        )
                        if st.button("Enhance", key=f"ls_enhance_{n}"):
                            with st.spinner("Enhancing..."):
                                try:
                                    updated_scene = {**scene, "scene_description": new_desc, "dialogue": new_dialogue, "character": new_char}
                                    updated = _enhance_lipsync_scene(updated_scene, enhance_prompt, provider)
                                    script["scenes"][i] = updated
                                    st.session_state["script_data"] = script
                                    st.rerun()
                                except Exception as e:
                                    st.error(f"Enhance failed: {e}")

                with col_gen:
                    char_img = char_map.get(new_char, "")
                    if not char_img and len(char_map) == 1:
                        char_img = next(iter(char_map.values()))
                    if char_img and Path(char_img).exists():
                        st.image(char_img, width=60, caption="Ref image")
                    else:
                        st.caption("No ref image")
                    if st.button("Generate clip", key=f"ls_gen_{n}", type="primary"):
                        st.session_state["script_data"] = script
                        _ls_vr = st.session_state.get("voice_ref_upload_path") or ""
                        _ls_vr_path = Path(_ls_vr) if _ls_vr and Path(_ls_vr).exists() else None
                        if _ls_vr_path is None and n > 1:
                            _s1_clip = output_dir / "clips" / "scene1_lipsync.mp4"
                            if _s1_clip.exists():
                                try:
                                    _ls_vr_path = _extract_audio_from_clip(_s1_clip)
                                except Exception:
                                    pass
                        _generate_lipsync_clip(
                            {**scene, "scene_description": new_desc, "dialogue": new_dialogue},
                            char_img,
                            output_dir,
                            voice_ref=_ls_vr_path,
                        )

    st.session_state["script_data"] = script

    st.markdown("---")
    if st.button("Generate All", type="primary"):
        from core.higgsfield_cli import generate_image as _gen_img, _extract_url as _ext_url
        from utils.downloader import download_file as _dl
        scenes_list = script.get("scenes", [])
        images_dir = output_dir / "images"
        images_dir.mkdir(exist_ok=True)
        placeholders = [st.empty() for _ in scenes_list]

        clips_dir = output_dir / "clips"
        clips_dir.mkdir(exist_ok=True)

        def _gen_info(scene, ph, vref: Path = None):
            from utils.cli_runner import run_higgsfield as _rhf
            img_prompt = scene.get("image_prompt", "") or scene.get("scene_description", "")
            narration = scene.get("dialogue", "") or scene.get("narration", "")
            n = scene["scene_number"]
            img_dest = images_dir / f"scene{n}_infographic.jpg"
            clip_dest = clips_dir / f"scene{n}_infographic.mp4"
            if not img_dest.exists():
                try:
                    cdn_url = _ext_url(_gen_img(img_prompt, aspect_ratio="9:16"))
                    _dl(cdn_url, img_dest)
                    scene["image_path"] = str(img_dest)
                except Exception as e:
                    ph.error(f"Scene {n} image failed: {e}")
                    return
            else:
                scene["image_path"] = str(img_dest)
            ph.image(str(img_dest), caption=f"Scene {n} image")
            if clip_dest.exists():
                scene["clip_path"] = str(clip_dest)
                ph.video(clip_dest.read_bytes())
                return clip_dest
            # Use user-edited Seedance prompt if available, else build from scene data
            anim_prompt = (
                st.session_state.get(f"scene_prompt_override_{n}")
                or (f"{img_prompt}. Narration: {narration}" if narration else img_prompt)
            )
            try:
                cmd = [
                    "generate", "create", st.session_state.get("animation_model", "seedance_2_0_mini"),
                    "--prompt", anim_prompt,
                    "--image", str(img_dest),
                    "--aspect_ratio", "9:16",
                    "--duration", "8",
                    "--mode", config.HIGGSFIELD_VIDEO_MODE,
                    "--generate_audio", "true",
                    "--resolution", config.HIGGSFIELD_VIDEO_RESOLUTION,
                ]
                if vref and vref.exists():
                    cmd += ["--audio", str(vref)]
                cdn_url = _ext_url(_rhf(cmd))
                _dl(cdn_url, clip_dest)
                scene["clip_path"] = str(clip_dest)
                ph.video(clip_dest.read_bytes())
                return clip_dest
            except Exception as e:
                ph.error(f"Scene {n} animation failed: {e}")

        # Scene 1 runs first to establish voice ref (regardless of type)
        _ls_uploaded = st.session_state.get("voice_ref_upload_path") or ""
        voice_ref: Path | None = Path(_ls_uploaded) if _ls_uploaded and Path(_ls_uploaded).exists() else None
        first_scene, first_ph = scenes_list[0], placeholders[0]
        first_stype = first_scene.get("scene_type", "LIPSYNC")
        if first_stype == "LIPSYNC":
            char = first_scene.get("character", "")
            cimg = char_map.get(char, "") or (next(iter(char_map.values())) if len(char_map) == 1 else "")
            first_dest = _generate_lipsync_clip(first_scene, cimg, output_dir, placeholder=first_ph, voice_ref=voice_ref)
            if first_dest and voice_ref is None:
                try:
                    voice_ref = _extract_audio_from_clip(first_dest)
                except Exception:
                    pass
        else:
            first_dest = _gen_info(first_scene, first_ph, vref=voice_ref)
            if first_dest and voice_ref is None:
                try:
                    voice_ref = _extract_audio_from_clip(first_dest)
                except Exception:
                    pass

        def _gen_card(scene, ph):
            n = scene["scene_number"]
            (output_dir / "cards").mkdir(exist_ok=True)
            (output_dir / "clips").mkdir(exist_ok=True)
            card_img_dest  = output_dir / "cards" / f"scene{n}_textcard.jpg"
            card_clip_dest = output_dir / "clips" / f"scene{n}_textcard.mp4"
            _card_dict = {"overlay_text": scene.get("overlay_text", ""), "image_prompt": scene.get("image_prompt", "")}
            try:
                cdn_url = _ext_url(_gen_img(_build_card_image_prompt(_card_dict), aspect_ratio="9:16"))
                _dl(cdn_url, card_img_dest)
                scene["image_path"] = str(card_img_dest)
                ph.image(str(card_img_dest), caption=f"Scene {n} card")
            except Exception as e:
                ph.error(f"Scene {n} card image failed: {e}")
                return
            try:
                _text_ref = f'Text: "{_card_dict["overlay_text"]}".' if _card_dict["overlay_text"] else ""
                cmd = [
                    "generate", "create", st.session_state.get("animation_model", "seedance_2_0_mini"),
                    "--prompt", f"{_CARD_ANIM_PROMPT} {_text_ref}".strip(),
                    "--image", str(card_img_dest),
                    "--aspect_ratio", "9:16",
                    "--duration", "4",
                    "--mode", "fast",
                    "--generate_audio", "true",
                    "--resolution", "480p",
                ]
                cdn_url = _ext_url(_rhf(cmd))
                _dl(cdn_url, card_clip_dest)
                scene["clip_path"] = str(card_clip_dest)
                ph.video(card_clip_dest.read_bytes())
            except Exception as e:
                ph.error(f"Scene {n} card animation failed: {e}")

        # Remaining scenes in parallel, all with voice ref
        tasks = []
        _vref = voice_ref  # pin value before lambda capture
        for scene, ph in zip(scenes_list[1:], placeholders[1:]):
            stype = scene.get("scene_type", "LIPSYNC")
            if stype == "INFOGRAPHIC":
                tasks.append(lambda s=scene, p=ph, v=_vref: _gen_info(s, p, vref=v))
            elif stype == "TEXT_CARD":
                tasks.append(lambda s=scene, p=ph: _gen_card(s, p))
            elif stype == "LIPSYNC":
                char = scene.get("character", "")
                cimg = char_map.get(char, "") or (next(iter(char_map.values())) if len(char_map) == 1 else "")
                tasks.append(lambda s=scene, c=cimg, p=ph, v=_vref: _generate_lipsync_clip(s, c, output_dir, placeholder=p, voice_ref=v))
        if tasks:
            _run_async_batch(tasks, max_workers=3)
        st.session_state["script_data"] = script


# ═══════════════════════════════════════════════════════════════════════════════
# Router
# ═══════════════════════════════════════════════════════════════════════════════
screen = st.session_state["screen"]

if screen == "input":
    screen_input()
elif screen == "review":
    screen_review()
elif screen == "lipsync_review":
    screen_lipsync_review()
elif screen == "progress":
    screen_progress()
elif screen == "reanimate":
    screen_reanimate()
elif screen == "output":
    screen_output()
