# Type 1 Lipsync + Type 2 Restructure Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Restructure the pipeline into Type 1 (Lipsync — user-provided script) and Type 2 (Complete Generation — modes 1/2/3), renaming the backend video_type values throughout.

**Architecture:** Type 1 is a new BYOS (bring your own script) path: user pastes raw script + uploads character images → LLM formats into scenes → user edits/enhances per scene → generates 10s Higgsfield clips per scene. Type 2 wraps the existing type1/type2/drama as mode1/mode2/mode3, adding character image upload to mode1 and mode2. All video_type string values renamed in backend.

**Tech Stack:** Streamlit, Python, Higgsfield CLI (seedance_2_0), OpenRouter/Groq/Claude for LLM, existing pipeline helpers.

---

### Task 1: Rename video_type values in backend

**Files:**
- Modify: `config.py`
- Modify: `core/script_generator.py`
- Modify: `app.py`
- Modify: `prompts.py`
- Modify: `stitch.py`

- [ ] **Step 1: Update config.py** — no constants reference type strings directly, but add the new lipsync type marker for reference. No change needed here beyond a comment. Skip.

- [ ] **Step 2: Rename in script_generator.py** — find all `"type1"`, `"type2"`, `"drama"` video_type string assignments and replace:
  - `"type1"` → `"mode1"`
  - `"type2"` → `"mode2"`
  - `"drama"` → `"mode3"`

  In `generate_script()`, the returned dict sets `video_type`. Find these lines and update.

- [ ] **Step 3: Rename in app.py** — all references to video_type string values:
  - `_vt_options = ["type1", "type2", "drama"]` → `["mode1", "mode2", "mode3"]`
  - All comparisons: `video_type == "type1"` → `"mode1"`, etc.
  - `_init_state` default: `"video_type": "type1"` → `"mode1"`
  - Format labels in radio button
  - `_save_edit_timeline` reference
  - Upload script check: `data.get("video_type") != "drama"` → `"mode3"`

- [ ] **Step 4: Rename in stitch.py** — `if video_type == "drama"` → `"mode3"`, `elif video_type == "type2"` → `"mode2"`

- [ ] **Step 5: Rename in prompts.py** — search for any type string references. Likely none, but verify.

- [ ] **Commit:**
```bash
git add app.py core/script_generator.py stitch.py prompts.py
git commit -m "refactor: rename video_type values type1/2/drama → mode1/2/mode3"
```

---

### Task 2: Add character image upload to Mode 1 and Mode 2 input screen

**Files:**
- Modify: `app.py` — `screen_input()` function

- [ ] **Step 1:** In `screen_input()`, after the HeyGen toggle block, add a character image upload section that appears when `video_type in ("mode1", "mode2")`:

```python
if video_type in ("mode1", "mode2"):
    st.markdown("---")
    st.markdown("### Character Images (optional)")
    st.caption("Upload character reference images. Selected image will be used for avatar scenes instead of HeyGen default.")
    char_img_file = st.file_uploader(
        "Character image (JPG/PNG)",
        type=["jpg", "jpeg", "png"],
        key="mode_char_img",
        label_visibility="collapsed",
    )
    if char_img_file:
        tmp_dir = config.OUTPUT_DIR / "_avatars"
        tmp_dir.mkdir(exist_ok=True)
        save_path = str(tmp_dir / char_img_file.name)
        with open(save_path, "wb") as f:
            f.write(char_img_file.read())
        st.session_state["avatar_image_path"] = save_path
        st.caption(f"Character image: {char_img_file.name}")
```

- [ ] **Commit:**
```bash
git add app.py
git commit -m "feat: add character image upload to Mode 1 and Mode 2 input"
```

---

### Task 3: Add lipsync script formatter in script_generator.py

**Files:**
- Modify: `core/script_generator.py`
- Modify: `prompts.py`

- [ ] **Step 1:** Add `LIPSYNC_FORMAT_PROMPT` to `prompts.py`:

```python
LIPSYNC_FORMAT_PROMPT = """You are a video production script formatter for the AMPM pipeline.

The user will provide a raw script and a list of character names.
Format it into a structured scene-by-scene JSON for a 10-second-per-scene lipsync video.

HARD RULES:
- Each scene is exactly 10 seconds
- Dialogue spoken words per scene: MAX 25 words (10 seconds at normal pace)
- Strip [beat], [pause Xs] before counting words — they are NOT words
- scene_description: what is visually happening (for Higgsfield image/animation prompt)
- dialogue: the actual spoken words for this scene only
- character: must exactly match one of the provided character names
- scene_number: sequential starting from 1

Return ONLY valid JSON. No markdown. No commentary. No preamble.

Schema:
{
  "video_id": "LIPSYNC-<SLUG>-YYYYMMDD-HHMM",
  "video_type": "lipsync",
  "total_scenes": <number>,
  "scenes": [
    {
      "scene_number": 1,
      "character": "<character name>",
      "scene_description": "<visual description for Higgsfield — what is shown, setting, action, camera>",
      "dialogue": "<spoken words only — max 25 words>",
      "duration_seconds": 10
    }
  ]
}
"""
```

- [ ] **Step 2:** Add `format_lipsync_script()` function in `core/script_generator.py`:

```python
def format_lipsync_script(
    raw_script: str,
    characters: list[str],
    provider: str = "groq",
) -> dict:
    """
    Takes a raw user script and character names, returns structured lipsync scene JSON.
    """
    from datetime import datetime
    char_list = ", ".join(characters) if characters else "Character 1"
    date_str = datetime.now().strftime("%Y%m%d-%H%M")

    user_msg = f"""Characters: {char_list}

Raw script:
---
{raw_script.strip()}
---

Format this into scene-by-scene lipsync JSON. Date for video_id: {date_str}"""

    system_prompt = prompts.LIPSYNC_FORMAT_PROMPT

    if provider == "groq":
        raw = _call_groq(system_prompt, user_msg)
    elif provider == "claude":
        raw = _call_claude(system_prompt, user_msg)
    elif provider.startswith("openrouter"):
        model = config.OPENROUTER_DEEPSEEK_MODEL
        raw = _call_openrouter(system_prompt, user_msg, model=model)
    else:
        raw = _call_groq(system_prompt, user_msg)

    data = _extract_json(raw)
    return data
```

- [ ] **Commit:**
```bash
git add core/script_generator.py prompts.py
git commit -m "feat: add format_lipsync_script and LIPSYNC_FORMAT_PROMPT"
```

---

### Task 4: Add Type 1 Lipsync input screen section in app.py

**Files:**
- Modify: `app.py`

- [ ] **Step 1:** In `_init_state()`, add new lipsync-specific state keys:

```python
"lipsync_characters": [],   # list of {"name": str, "image_path": str}
"lipsync_script_raw": "",
```

- [ ] **Step 2:** In `screen_input()`, update the video format radio to include `"lipsync"`:

```python
_vt_options = ["lipsync", "mode1", "mode2", "mode3"]
format_func=lambda x: {
    "lipsync": "Type 1 — Lipsync (your script + character images)",
    "mode1":   "Type 2 Mode 1 — Standard (2 avatar + 4 cutaway, 60s)",
    "mode2":   "Type 2 Mode 2 — Split-screen (2 avatar 30s + 10 cutaway 5s)",
    "mode3":   "Type 2 Mode 3 — Micro-Drama (2 characters, dialogue, 60s)",
}[x]
```

- [ ] **Step 3:** Add a conditional block in `screen_input()` — when `video_type == "lipsync"`, show the lipsync-specific inputs instead of the standard topic/beat/news inputs:

```python
if video_type == "lipsync":
    _render_lipsync_input()
    return   # skip standard input form
```

- [ ] **Step 4:** Implement `_render_lipsync_input()` function:

```python
def _render_lipsync_input():
    st.markdown("### Script")
    raw_script = st.text_area(
        "Paste your script",
        height=300,
        placeholder="Scene 1: Mayank stands near the door...\nDialogue: Bhai, darwaza band kar...",
        key="lipsync_script_raw",
    )

    st.markdown("### Characters")
    st.caption("Add each character by name and upload their reference image.")

    chars = st.session_state.get("lipsync_characters", [])

    # Add character form
    col_name, col_img, col_add = st.columns([2, 2, 1])
    with col_name:
        new_char_name = st.text_input("Character name", key="new_char_name", label_visibility="collapsed", placeholder="e.g. Mayank")
    with col_img:
        new_char_img = st.file_uploader("Image", type=["jpg","jpeg","png"], key="new_char_img", label_visibility="collapsed")
    with col_add:
        if st.button("Add", use_container_width=True):
            if new_char_name.strip():
                img_path = ""
                if new_char_img:
                    tmp_dir = config.OUTPUT_DIR / "_avatars"
                    tmp_dir.mkdir(exist_ok=True)
                    img_path = str(tmp_dir / new_char_img.name)
                    with open(img_path, "wb") as f:
                        f.write(new_char_img.read())
                chars.append({"name": new_char_name.strip(), "image_path": img_path})
                st.session_state["lipsync_characters"] = chars
                st.rerun()

    # Show existing characters
    for i, char in enumerate(chars):
        col_c, col_del = st.columns([4, 1])
        with col_c:
            img_label = Path(char["image_path"]).name if char["image_path"] else "no image"
            st.caption(f"**{char['name']}** — {img_label}")
            if char["image_path"] and Path(char["image_path"]).exists():
                st.image(char["image_path"], width=80)
        with col_del:
            if st.button("Remove", key=f"rm_char_{i}"):
                chars.pop(i)
                st.session_state["lipsync_characters"] = chars
                st.rerun()

    st.markdown("---")
    _active_provider = st.session_state.get("llm_provider", "groq")
    can_format = bool(raw_script.strip())
    if not can_format:
        st.warning("Paste your script above to continue.")

    if st.button("Format Script into Scenes", type="primary", disabled=not can_format):
        char_names = [c["name"] for c in chars] if chars else ["Character 1"]
        with st.spinner("Formatting script into scenes..."):
            try:
                from core.script_generator import format_lipsync_script
                script_data = format_lipsync_script(
                    raw_script=raw_script.strip(),
                    characters=char_names,
                    provider=_active_provider,
                )
                video_dir = config.OUTPUT_DIR / script_data["video_id"]
                video_dir.mkdir(parents=True, exist_ok=True)
                (video_dir / "script.json").write_text(
                    json.dumps(script_data, indent=2, ensure_ascii=False), encoding="utf-8"
                )
                st.session_state["script_data"] = script_data
                st.session_state["video_id"] = script_data["video_id"]
                st.session_state["output_dir"] = str(video_dir)
                st.session_state["screen"] = "lipsync_review"
                st.rerun()
            except Exception as e:
                st.error(f"Script formatting failed: {e}")
```

- [ ] **Commit:**
```bash
git add app.py
git commit -m "feat: add Type 1 Lipsync input screen and _render_lipsync_input"
```

---

### Task 5: Add Lipsync review screen (scene cards with enhance + generate)

**Files:**
- Modify: `app.py`

- [ ] **Step 1:** Add `_enhance_lipsync_scene()` helper:

```python
def _enhance_lipsync_scene(scene: dict, enhance_prompt: str, provider: str) -> dict:
    """Calls LLM to enhance scene_description + dialogue based on user enhance_prompt."""
    from core.script_generator import _call_groq, _call_claude, _extract_json
    import prompts

    system = (
        "You are a video scene director. Enhance the given scene for a 10-second lipsync clip. "
        "Return ONLY valid JSON with keys: scene_description, dialogue. "
        "dialogue max 25 spoken words. No markdown. No commentary."
    )
    user_msg = (
        f"Current scene_description: {scene.get('scene_description', '')}\n"
        f"Current dialogue: {scene.get('dialogue', '')}\n"
        f"Character: {scene.get('character', '')}\n"
        f"Enhancement instruction: {enhance_prompt or 'Make it more cinematic and emotionally impactful.'}"
    )
    if provider == "groq":
        raw = _call_groq(system, user_msg)
    else:
        raw = _call_claude(system, user_msg)
    result = _extract_json(raw)
    scene["scene_description"] = result.get("scene_description", scene["scene_description"])
    scene["dialogue"] = result.get("dialogue", scene["dialogue"])
    return scene
```

- [ ] **Step 2:** Add `_generate_lipsync_clip()` helper:

```python
def _generate_lipsync_clip(scene: dict, char_image_path: str, output_dir: Path):
    """Generates a 10s Higgsfield seedance_2_0 clip for one lipsync scene."""
    from core.higgsfield_cli import _extract_url
    from utils.cli_runner import run_higgsfield
    from utils.downloader import download_file
    import re as _re

    clips_dir = output_dir / "clips"
    clips_dir.mkdir(exist_ok=True)
    n = scene["scene_number"]
    dest = clips_dir / f"scene{n}_lipsync.mp4"

    if dest.exists():
        st.success(f"Scene {n} already generated — skipping.")
        st.video(dest.read_bytes())
        return

    dialogue = _re.sub(r"\[.*?\]", "", scene.get("dialogue", "")).strip()
    desc = scene.get("scene_description", "")
    full_prompt = f"{desc} Dialogue: {dialogue}" if dialogue else desc

    cmd = [
        "generate", "create", "seedance_2_0",
        "--prompt", full_prompt,
        "--aspect_ratio", "9:16",
        "--duration", "8",
        "--mode", "fast",
        "--generate_audio", "true",
        "--resolution", "480p",
    ]
    if char_image_path and Path(char_image_path).exists():
        cmd += ["--image", char_image_path]

    with st.spinner(f"Generating scene {n} (Seedance 8s)..."):
        try:
            response = run_higgsfield(cmd)
            cdn_url = _extract_url(response)
            download_file(cdn_url, dest)
            st.success(f"Scene {n} done")
            st.video(dest.read_bytes())
        except Exception as e:
            st.error(f"Scene {n} failed: {e}")
```

- [ ] **Step 3:** Add `screen_lipsync_review()` function:

```python
def screen_lipsync_review():
    script = st.session_state["script_data"]
    chars = st.session_state.get("lipsync_characters", [])
    output_dir = Path(st.session_state["output_dir"])
    provider = st.session_state.get("llm_provider", "groq")

    # Build char lookup: name → image_path
    char_map = {c["name"]: c["image_path"] for c in chars}

    if st.button("← Back to input", key="lipsync_review_back"):
        st.session_state["screen"] = "input"
        st.rerun()

    st.markdown(f"## Lipsync Script Review — `{script['video_id']}`")
    st.caption(f"{script.get('total_scenes', 0)} scenes · 10s each · {script.get('total_scenes', 0) * 10}s total")

    scenes = script.get("scenes", [])
    char_names = [c["name"] for c in chars] if chars else ["Character 1"]

    for i, scene in enumerate(scenes):
        n = scene["scene_number"]
        with st.expander(f"Scene {n} — {scene.get('character', '')}  |  10s", expanded=True):

            # Editable fields
            new_desc = st.text_area(
                "Scene description",
                value=scene.get("scene_description", ""),
                key=f"ls_desc_{n}",
                height=100,
            )
            new_dialogue = st.text_area(
                "Dialogue",
                value=scene.get("dialogue", ""),
                key=f"ls_dial_{n}",
                height=80,
            )

            # Word count check
            import re as _re
            spoken = _re.sub(r"\[.*?\]", "", new_dialogue).strip()
            wc = len(spoken.split()) if spoken else 0
            if wc > 25:
                st.warning(f"{wc} spoken words — max 25 for 10s. Trim before generating.")
            else:
                st.caption(f"{wc}/25 words")

            # Character dropdown
            new_char = st.selectbox(
                "Character",
                char_names,
                index=char_names.index(scene.get("character", char_names[0])) if scene.get("character") in char_names else 0,
                key=f"ls_char_{n}",
            )

            # Save edits back
            script["scenes"][i]["scene_description"] = new_desc
            script["scenes"][i]["dialogue"] = new_dialogue
            script["scenes"][i]["character"] = new_char

            # Enhance button
            col_enh, col_gen = st.columns([2, 1])
            with col_enh:
                with st.expander("Enhance this scene"):
                    enhance_prompt = st.text_input(
                        "Enhancement instruction (optional)",
                        placeholder="Make it more tense, add rain, closer shot...",
                        key=f"ls_enh_prompt_{n}",
                        label_visibility="collapsed",
                    )
                    if st.button("Enhance", key=f"ls_enhance_{n}"):
                        with st.spinner("Enhancing..."):
                            try:
                                updated = _enhance_lipsync_scene(scene, enhance_prompt, provider)
                                script["scenes"][i] = updated
                                st.session_state["script_data"] = script
                                st.rerun()
                            except Exception as e:
                                st.error(f"Enhance failed: {e}")

            with col_gen:
                char_img = char_map.get(new_char, "")
                if st.button("Generate clip", key=f"ls_gen_{n}", type="primary"):
                    st.session_state["script_data"] = script
                    _generate_lipsync_clip(scene, char_img, output_dir)

    st.session_state["script_data"] = script
```

- [ ] **Step 4:** Wire `screen_lipsync_review` into the router at the bottom of `app.py`:

```python
elif screen == "lipsync_review":
    screen_lipsync_review()
```

- [ ] **Commit:**
```bash
git add app.py
git commit -m "feat: add Type 1 Lipsync review screen with enhance + per-scene generate"
```

---

### Task 6: Final wiring + cleanup

**Files:**
- Modify: `app.py`

- [ ] **Step 1:** Update the Reset button state clear to also clear lipsync state:
```python
st.session_state["lipsync_characters"] = []
st.session_state["lipsync_script_raw"] = ""
```

- [ ] **Step 2:** Update the sidebar video type label display to reflect the new structure:
```python
# Where screen_input shows format caption, update for lipsync
elif video_type == "lipsync":
    st.caption("Type 1: Paste your own script. Format into scenes. Generate each clip individually.")
```

- [ ] **Step 3:** Update `screen_input()` `can_generate` logic to skip lipsync path (lipsync has its own submit button inside `_render_lipsync_input`, so the main Generate Script button should not appear for lipsync):
```python
if video_type == "lipsync":
    _render_lipsync_input()
    return
```

- [ ] **Commit:**
```bash
git add app.py
git commit -m "feat: wire lipsync reset, sidebar labels, router cleanup"
```

---

## Self-Review

**Spec coverage:**
- [x] Type 1 Lipsync: raw script input → format → scene cards → editable → enhance → generate per scene
- [x] Character image upload with multiple characters + named
- [x] Character selection dropdown per scene
- [x] Enhance button with optional prompt, opens input on click
- [x] Generate button per scene, 10s clips
- [x] Word count enforced at scene level (WARN at >25 words)
- [x] Type 2 Mode 1 + Mode 2 get character image upload
- [x] Mode 3 (drama) untouched
- [x] Backend rename: type1→mode1, type2→mode2, drama→mode3

**No placeholders:** all code blocks are complete.
