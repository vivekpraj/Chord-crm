import { NextResponse } from 'next/server';
import { createAdminClient } from '@/lib/supabase/admin';
import { notifyHarmonySlack } from '@/lib/slack';
import { getAuthedPerson } from '@/lib/supabase/get-authed-person';

export const runtime = 'nodejs';

export async function GET(req: Request) {
  const { person, unauth } = await getAuthedPerson();
  if (unauth) return unauth;

  const { searchParams } = new URL(req.url);
  const person_id = searchParams.get('person_id');
  const month = searchParams.get('month'); // YYYY-MM-01

  if (!person_id || !month) return NextResponse.json({ error: 'missing params' }, { status: 400 });

  const isPrivileged = ['admin', 'lead', 'operations'].includes((person as any)?.access_tier);
  if (!isPrivileged && (person as any)?.id !== person_id) {
    return NextResponse.json({ error: 'forbidden' }, { status: 403 });
  }

  const admin = createAdminClient();

  const { data: rawAssignments } = await admin
    .rpc('get_harmony_assignments', { p_person_id: person_id });

  const assignments = (rawAssignments ?? []).map((r: any) => ({
    brand_id: r.brand_id,
    role_type: r.role_type,
    brands: { id: r.brand_id, name: r.brand_name },
  }));

  const { data: entries } = await admin
    .from('harmony_core_monthly')
    .select('*')
    .eq('person_id', person_id)
    .eq('month', month);

  // Auto-carry: for social brands with no current-month entry but with remaining scope last month,
  // seed this month's backlog automatically.
  const prevMonthDate = new Date(month + 'T00:00:00');
  prevMonthDate.setMonth(prevMonthDate.getMonth() - 1);
  const prevMonth = `${prevMonthDate.getFullYear()}-${String(prevMonthDate.getMonth() + 1).padStart(2, '0')}-01`;

  const { data: prevEntries } = await admin
    .from('harmony_core_monthly')
    .select('*')
    .eq('person_id', person_id)
    .eq('month', prevMonth);

  const existingBrandIds = new Set((entries ?? []).map((e: any) => e.brand_id));
  const carriedBrands: string[] = [];

  for (const prev of prevEntries ?? []) {
    if (prev.role_type !== 'social') continue;
    const m = prev.metrics ?? {};
    const remaining = Math.max(0, (Number(m.scope) || 0) - (Number(m.tasks_completed) || 0));
    if (remaining === 0) continue;

    if (!existingBrandIds.has(prev.brand_id)) {
      await admin.from('harmony_core_monthly').upsert(
        {
          person_id,
          brand_id: prev.brand_id,
          month,
          role_type: 'social',
          metrics: { backlog: remaining },
          tracker_logs: { orm: [], ops: [], social: [] },
          updated_at: new Date().toISOString(),
        },
        { onConflict: 'person_id,brand_id,month' }
      );
      carriedBrands.push(prev.brand_id);
    }
  }

  // Re-fetch if we seeded anything
  const finalEntries = carriedBrands.length
    ? (await admin.from('harmony_core_monthly').select('*').eq('person_id', person_id).eq('month', month)).data ?? []
    : entries ?? [];

  return NextResponse.json({ assignments: assignments ?? [], entries: finalEntries, carried_brands: carriedBrands });
}

export async function POST(req: Request) {
  const { person: me, unauth } = await getAuthedPerson('id, access_tier');
  if (unauth) return unauth;

  const body = await req.json();
  const { person_id, brand_id, month, role_type, metrics, tracker_logs } = body;

  // Only admin or the person themselves can write
  if ((me as any)?.access_tier !== 'admin' && (me as any)?.id !== person_id) {
    return NextResponse.json({ error: 'forbidden' }, { status: 403 });
  }

  const admin = createAdminClient();

  const { data, error } = await admin
    .from('harmony_core_monthly')
    .upsert(
      { person_id, brand_id, month, role_type, metrics, tracker_logs, updated_at: new Date().toISOString() },
      { onConflict: 'person_id,brand_id,month' }
    )
    .select()
    .single();

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });

  const { data: personRow } = await admin.from('people').select('name').eq('id', person_id).maybeSingle();
  const { data: brandRow } = await admin.from('brands').select('name').eq('id', brand_id).maybeSingle();
  const monthLabel = new Date(month + 'T00:00:00').toLocaleString('en', { month: 'long', year: 'numeric' });
  notifyHarmonySlack(`${personRow?.name ?? person_id} updated ${brandRow?.name ?? brand_id} for ${monthLabel}`);

  return NextResponse.json({ data });
}
